#!/usr/bin/env python3
# patch4x2.py: applies the X2 changes to a clean copy of base4/index.html
# usage: python3 patch4x2.py [in.html] [out.html]
import sys
SRC=sys.argv[1] if len(sys.argv)>1 else '/home/claude/work/base4/index.html'
DST=sys.argv[2] if len(sys.argv)>2 else '/home/claude/work/x2/index.html'
OPS=[('rep', 'const F={auto:!rm&&!!A, hold:0, on:false,', 'const F={auto:!rm&&!!A, hold:(A&&A.start)?performance.now()+A.start:0, on:false,', 1),
 ('reg',
  '  /* keep the best-flat label clear of the person avatars on the AI Home Plan map */\n  function dodge(el){',
  '  return {attach,hintText,seen,dodge};',
  '  /* keep every price label of the AI Home Plan map clear of the person avatars, score chips, controls and of each other (x2) */\n'
  '  function dodge(el){\n'
  "    const labs=[...el.querySelectorAll('.pl2')]; if(!labs.length) return;\n"
  "    const ph=+el.dataset.ph||0, out=el.dataset.zoom==='out';\n"
  '    const sr=el.getBoundingClientRect(); const M=2;\n'
  '    const R=q=>({l:q.left-M,t:q.top-M,r:q.right+M,b:q.bottom+M});\n'
  "    const obs=[]; if(ph>=3) el.querySelectorAll('.ps-nd,.ps-ed').forEach(n=>obs.push(R(n.getBoundingClientRect())));\n"
  "    el.querySelectorAll('.ps-st,.ps-skip,.cn3-ctl,.cn3-hint').forEach(n=>{ const q=n.getBoundingClientRect(); if(q.width) obs.push(R(q)); });\n"
  '    const items=[];\n'
  '    labs.forEach(b=>{\n'
  "      const i=b.firstElementChild; if(!i||b.style.transform.indexOf('-999')>-1) return;\n"
  "      const best=b.classList.contains('best'), au=b.classList.contains('aitu'), on=b.classList.contains('on');\n"
  "      if(!best&&!au&&!on&&!b.classList.contains('show')) return;\n"
  '      if(out&&!best&&!au&&!on) return;\n'
  '      const q=i.getBoundingClientRect(); if(!q.width) return;\n'
  '      const ox=i.__ox||0, oy=i.__oy||0;\n'
  '      items.push({b,i,ox,oy,l:q.left-ox,t:q.top-oy,w:q.width,h:q.height,pr:best?0:au?1:on?2:3});\n'
  '    });\n'
  '    items.sort((a,c)=>a.pr-c.pr);\n'
  '    const placed=[]; const hit=(x,y,w,h)=>obs.some(o=>x<o.r&&x+w>o.l&&y<o.b&&y+h>o.t)||placed.some(o=>x<o.r&&x+w>o.l&&y<o.b&&y+h>o.t);\n'
  '    const inside=(x,y,w,h)=>x>=sr.left+3&&x+w<=sr.right-3&&y>=sr.top+56&&y+h<=sr.bottom-4;\n'
  '    items.forEach(it=>{\n'
  '      const {w,h}=it; const cand=[[it.ox,it.oy],[0,0]];\n'
  '      const dirs=[[0,-1],[0,1],[-1,0],[1,0],[-1,-1],[1,-1],[-1,1],[1,1]];\n'
  '      for(let k=1;k<=3;k++) dirs.forEach(([dx,dy])=>cand.push([dx*(w*.55+3)*k,dy*(h+3)*k]));\n'
  '      let ok=cand.find(([dx,dy])=>inside(it.l+dx,it.t+dy,w,h)&&!hit(it.l+dx,it.t+dy,w,h));\n'
  '      let hide=false;\n'
  '      if(!ok){ if(it.pr<=1) ok=[0,0]; else { ok=[0,0]; hide=true; } }\n'
  "      it.b.classList.toggle('cn-hid',hide);\n"
  '      if(!hide) placed.push({l:it.l+ok[0]-M,t:it.t+ok[1]-M,r:it.l+ok[0]+w+M,b:it.t+ok[1]+h+M});\n'
  "      if(ok[0]!==it.ox||ok[1]!==it.oy){ it.i.__ox=ok[0]; it.i.__oy=ok[1]; it.i.style.setProperty('--ox',ok[0].toFixed(1)+'px'); it.i.style.setProperty('--oy',ok[1].toFixed(1)+'px'); }\n"
  '    });\n'
  '  }\n'),
 ('rep', 'if(el.dataset.ph>=3) CN3D.dodge(el);', 'if(+el.dataset.ph>=1) CN3D.dodge(el);', 1),
 ('rep',
  "limits:{yaw:[-85,85],pitch:[-90,-4],zoom:[.8,2]},sens:{yaw:.45,pitch:.2},topPitch:-88,wheel:'ctrl',panY:true,\n      auto:{mode:'sway',amp:26,period:13800,idle:2500},",
  "limits:{yaw:[-45,45],pitch:[-90,-4],zoom:[.8,2]},sens:{yaw:.45,pitch:.2},topPitch:-88,wheel:'ctrl',panY:true,dragStopsAuto:true,\n      auto:{mode:'sway',amp:14,period:13800,idle:2500},",
  1),
 ('rep',
  'const walls=[0,1,2,3].map(i=>pool[i%Math.max(1,pool.length)]);',
  'const walls=[0,1,2,3].map(i=>{ const p=pool[i%Math.max(1,pool.length)]; return (!p||i<pool.length)?p:[p[0],(p[1]+2)%4]; });',
  1),
 ('rep',
  "limits:{pitch:[-55,55],zoom:[.7,2.2]},sens:{yaw:-.35,pitch:.25},wheel:'always',keyScope:'window',dragStopsAuto:true,\n      auto:{mode:'spin',rate:7.2},",
  "limits:{pitch:[-20,20],zoom:[.7,2.2]},sens:{yaw:-.35,pitch:.25},wheel:'always',keyScope:'window',dragStopsAuto:true,\n      auto:{mode:'spin',rate:7.2,start:2000},",
  1),
 ('rep', 'const w=((Math.round(S.yaw/90)%4)+4)%4; setWall(', 'const w=((Math.round(-S.yaw/90)%4)+4)%4; setWall(', 1),
 ('rep',
  "    const esc=e=>{ if(e.key==='Escape') set(s=>{s.tour=null;}); };\n"
  "    window.addEventListener('keydown',esc);\n"
  "    return()=>{ ctl.destroy(); ctlRef.current=null; ro&&ro.disconnect(); window.removeEventListener('resize',fit); window.removeEventListener('keydown',esc); };",
  "    const esc=e=>{ if(e.key==='Escape') set(s=>{s.tour=null;}); };\n"
  "    window.addEventListener('keydown',esc);\n"
  '    const tr=tourOpen(); /* x2: scroll lock, focus trap, focus return */\n'
  "    return()=>{ ctl.destroy(); ctlRef.current=null; ro&&ro.disconnect(); window.removeEventListener('resize',fit); window.removeEventListener('keydown',esc); tr(); };",
  1),
 ('rep',
  'const turn=i=>{ const c=ctlRef.current; if(!c) return; const cur=Math.round(c.target().yaw/90); const base=cur-(((cur%4)+4)%4); c.to({yaw:(base+i)*90,pitch:0}); };',
  'const turn=i=>{ const c=ctlRef.current; if(!c) return; const cur=Math.round(c.target().yaw/90); let d=(((-i-cur)%4)+4)%4; if(d>2) d-=4; c.to({yaw:(cur+d)*90,pitch:0}); };',
  1),
 ('rep',
  '<div class="t3" role="dialog" aria-modal="true" aria-label=${\'3D tour: \'+l.title}>',
  '<div class="t3" role="dialog" aria-modal="true" tabindex="-1" aria-label=${\'3D tour: \'+l.title}>',
  1),
 ('rep',
  '<span>${kzt(l.price)} / month · 3D tour</span></div><button class="t3-x" autofocus aria-label="Close 3D tour"',
  '<span>${kzt(l.price)} / month · 360° preview</span></div><button class="t3-x" aria-label="Close 3D tour"',
  1),
 ('rep',
  '<div class="t3-view" ref=${viewRef} role="group" aria-roledescription="3D room view"',
  '<div class="t3-view" ref=${viewRef} tabindex="0" role="group" aria-roledescription="3D room view"',
  1),
 ('rep',
  "{t:'Welcome',c:'Campus Nest: a flat and the right roommates, planned by AI in seconds. A 90-second tour. Use ← → to move, Esc to stop.',d:6,",
  "{t:'Welcome',c:()=>'Campus Nest finds a flat and the right roommates for a student group. You will see AI Home Plan, matching, What-if and Contract X-ray in about 90 seconds. '+(CN_HOVER()?'Use ← "
  "→ to move, Esc to stop.':'Use the buttons below to move.'),d:6,",
  1),
 ('rep',
  "{t:'Say it in one sentence',c:'Type or dictate: group size, budget, a cat, no smokers. English, Russian and Kazakh work.',",
  "{t:'Say it in one sentence',c:'Type or dictate: group size, budget, a cat, no smokers. Code reads English and Russian well and Kazakh in part; the AI is not needed for this step.',",
  1),
 ('rep',
  "{t:'AI scans the city',c:'Code reads the request and filters flats by hard rules (pets, budget, rooms). The AI then picks the flat and roommates from what is left; offline, the rules pick.',d:10,",
  "{t:()=>aiLive()?'Code filters, AI decides':'Rules decide the plan',c:()=>(aiLive()?'Code reads the request and drops flats that break hard rules (pets, budget, rooms). The AI then picks the flat "
  "and roommates from what is left, and code verifies every pick. ':'No AI is connected, so the rules pick the flat and roommates themselves. ')+'The map lights up the flats the formula ranks "
  "highest and the camera flies to the chosen flat; both are drawn by code.',d:10,",
  1),
 ('rep',
  "{t:'A ready plan',c:'Best flat plus two backups, roommates, rent per person and why. “See how the AI decided” shows what the AI chose and what the code checked.',d:9,",
  "{t:'A ready plan',c:()=>{ const d=ST.plan&&ST.plan.dec; const ai=d&&(d.status==='ai'||d.status==='partial'); return 'Best flat plus two backups, roommates, rent per person and why. '+(ai?'The "
  "panel “See how the AI decided” shows what the AI chose and which checks the code ran. ':'This plan was made by the rules, no AI was used. ')+'Fit percentages always come from the formula.'; "
  '},d:9,',
  1),
 ('rep',
  "{t:'Rules and letter',c:'Three house rules and a draft letter to the landlord. Each part is tagged with who wrote it: the AI or the rules. Works offline too.',d:8,",
  "{t:'Rules and letter',c:'Three house rules and a draft letter to the landlord. Each part carries a tag that says who wrote it: the AI or the built-in rules. Without AI the rules write all of "
  "it.',d:8,",
  1),
 ('rep',
  "{t:'Send application',c:'One tap opens the application, already filled in with the lineup and the letter.',d:7,",
  "{t:'Send application',c:'One tap opens the application pre-filled with the plan’s lineup and the letter. Your saved group is not changed.',d:7,",
  1),
 ('rep',
  "{t:'Match moment',c:'A mutual like is a match. A chat opens right away.',d:8,",
  "{t:'Match moment',c:'A mutual like is a match and a chat opens right away. Match percentages come from a formula; the AI only explains them in words.',d:8,",
  1),
 ('rep',
  "{t:'What if…?',c:'Change your habits with sliders and see every score recalculate live.',d:11,",
  "{t:'What if…?',c:'Change your habits with sliders and every score is recalculated instantly by the formula. No AI call is involved.',d:11,",
  1),
 ('rep', "sheet('whatif'); later(()=>{ const a=document.activeElement;", "sheet('whatif'); PRES_SHEET=ST.sheet; later(()=>{ const a=document.activeElement;", 1),
 ('rep',
  "{t:'Contract X-ray',c:'Every clause is scanned: green is fine, yellow needs a question, red is a risk to negotiate.',d:12,",
  "{t:'Contract X-ray',c:'The clauses of the sample contract are rated by rules: green is fine, yellow needs a question, red is a risk to negotiate. When AI is available it writes the plain-words "
  "summary.',d:12,",
  1),
 ('rep',
  "{t:'That is Campus Nest',c:'Code scores and verifies, the AI decides the plan and explains. Everything also works offline. Press Reset demo to start over, or P to leave.',d:0,",
  "{t:'That is Campus Nest',c:()=>'Code filters, scores and verifies. In AI Home Plan the AI decides and code checks every part; elsewhere the AI only explains. Without AI the rules do the same job. "
  "Use Reset demo to start over'+(CN_HOVER()?', or P to leave.':'.'),d:0,",
  1),
 ('rep',
  "function presExit(){ presClear(); document.documentElement.classList.remove('cn-pres'); set(s=>{ s.pres={on:false,i:0,paused:false}; }); }",
  "function presExit(){ presClear(); document.documentElement.classList.remove('cn-pres'); const own=PRES_SHEET&&ST.sheet===PRES_SHEET; PRES_SHEET=null; set(s=>{ s.pres={on:false,i:0,paused:false}; "
  'if(own) s.sheet=null; }); }',
  1),
 ('rep', 'function presGo(i){ i=clamp(i,0,STEPS.length-1); presClear();', 'function presGo(i){ i=clamp(i,0,STEPS.length-1); presClear(); PRES_SHEET=null;', 1),
 ('rep', '<b>${S.t}</b>${S.c}</div>', '<b>${presT(S)}</b>${presC(S)}</div>', 1),
 ('reg',
  'function V2Layer(){\n  useEffect(()=>{',
  '  return html`${ST.planOpen&&html`<${PlanOverlay}/>`}<${PresenterBar}/>`;',
  'function V2Layer(){\n'
  '  useEffect(()=>{\n'
  '    const h=e=>{\n'
  '      if(e.metaKey||e.ctrlKey||e.altKey||e.defaultPrevented) return;\n'
  '      const t=e.target, L=presLayer(), typing=presTyping(t);\n'
  "      if((e.key==='p'||e.key==='P')){ if(typing||L) return; e.preventDefault(); presToggle(); return; }\n"
  '      if(!ST.pres.on) return;\n'
  "      if(e.key==='Escape'){ if(typing||L) return; e.stopPropagation(); e.preventDefault(); presExit(); return; }\n"
  "      if(typing||L||(t&&t.closest&&t.closest('[data-cn3]'))) return;\n"
  "      if(e.key==='ArrowRight'){ e.preventDefault(); presGo(ST.pres.i+1); } else if(e.key==='ArrowLeft'){ e.preventDefault(); presGo(ST.pres.i-1); }\n"
  '    };\n'
  "    window.addEventListener('keydown',h,true); return()=>window.removeEventListener('keydown',h,true);\n"
  '  },[]);\n'),
 ('rep',
  "  const wasOverlay=ST.planOpen; const members=['me',...pl.mates];\n"
  "  const pre={term:'10 months',pets:o.pet==='dog'?'Dog':o.pet?'Cat':'No pets',msg:P.letter};\n"
  "  planClear(); document.documentElement.classList.remove('cn-lock');\n"
  '  set(s=>{ s.planOpen=false; s.group.members=members; });',
  '  if(Date.now()-LAST_PLAN_SEND<900) return; LAST_PLAN_SEND=Date.now();\n'
  "  const wasOverlay=ST.planOpen; const members=['me',...pl.mates];\n"
  "  const pre={term:'10 months',pets:o.pet==='dog'?'Dog':o.pet?'Cat':'No pets',msg:P.letter,members};\n"
  "  planClear(); document.documentElement.classList.remove('cn-lock');\n"
  '  set(s=>{ s.planOpen=false; });',
  1),
 ('rep', "toast('Application is pre-filled from your plan');", "toast('Application is pre-filled from your plan. Your saved group is unchanged.');", 1),
 ('rep', 'Sending applies with this lineup as your group. ', 'Sending opens an application with this lineup. Your saved group stays as it is unless you change it there. ', 1),
 ('rep',
  "  const [msg,setMsg]=useState(cur().p?.pre?.msg||''); const people = grp?ST.group.members.length:1; const slot=ST.viewing[l.id];\n"
  "  const send = () => { set(s=>{ s.app={lid:l.id,group:grp,status:'pending',answers:{term,people,pets,move:date,viewing:slot||'Not booked',message:msg.trim()}}; s.ll.apps=null; }); "
  "toast('Application sent to '+LANDLORDS[l.ll].name); set(s=>{s.stack.student=[{id:'S0'},{id:'S4.3'}]}); };",
  "  const planM=cur().p?.pre?.members||null; const [lineup,setLineup]=useState(planM?'plan':'saved'); const members=(planM&&lineup==='plan')?planM:ST.group.members; const "
  'sendLock=useRef(Date.now()); const [sent,setSent]=useState(false);\n'
  "  const [msg,setMsg]=useState(cur().p?.pre?.msg||''); const people = grp?members.length:1; const slot=ST.viewing[l.id];\n"
  "  const nmOf=id=>id==='me'?'You':PEOPLE[id].name; const same=planM&&planM.join()===ST.group.members.join();\n"
  '  const send = () => { if(sendLock.current===true||Date.now()-sendLock.current<500) return; sendLock.current=true; setSent(true); LAST_APP_SENT=Date.now(); set(s=>{ '
  "s.app={lid:l.id,group:grp,members:grp?members.slice():['me'],status:'pending',answers:{term,people,pets,move:date,viewing:slot||'Not booked',message:msg.trim()}}; s.ll.apps=null; }); "
  "toast('Application sent to '+LANDLORDS[l.ll].name); set(s=>{s.stack.student=[{id:'S0'},{id:'S4.3'}]}); };",
  1),
 ('rep',
  '<div class="muted small">${grp?`${ST.group.name}, ${people} students · avg Trust ${groupStats().trustAvg}`:\'Only you\'}</div></div><${Sw} on=${grp} onClick=${()=>setGrp(!grp)} label="Apply as a '
  'group"/></div>${grp&&html`<div class="stack" style="margin-top:12px">${ST.group.members.map(id=>html`<${Av} id=${id} size=${36}/>`)}</div>`}</div>',
  '<div class="muted small">${grp?`${planM&&lineup===\'plan\'?\'Lineup from your plan\':ST.group.name}, ${people} students · avg Trust ${trustAvgOf(members)}`:\'Only you\'}</div></div><${Sw} '
  'on=${grp} onClick=${()=>setGrp(!grp)} label="Apply as a group"/></div>${grp&&html`<div class="stack" style="margin-top:12px">${members.map(id=>html`<${Av} id=${id} '
  'size=${36}/>`)}</div>`}${grp&&planM&&!same&&html`<div class="cn-lineup" role="group" aria-label="Who applies"><p>${lineup===\'plan\'?html`Applying with <b>${planM.map(nmOf).join(\', \')}</b>, the '
  "lineup from your plan. Your saved group (${ST.group.members.map(nmOf).join(', ')}) is not changed.`:html`Applying with your saved group <b>${ST.group.members.map(nmOf).join(', ')}</b>.`}</p><div "
  'class="btns"><button class="btn sm s" aria-pressed=${lineup===\'plan\'} onClick=${()=>setLineup(\'plan\')}>Apply with the plan lineup</button><button class="btn sm s" '
  'aria-pressed=${lineup===\'saved\'} onClick=${()=>setLineup(\'saved\')}>Use my saved group</button></div>${lineup===\'plan\'&&html`<button class="cn-lk" '
  "onClick=${()=>sheet('confirm',{title:'Replace your saved group?',text:'Your group would become '+planM.map(nmOf).join(', ')+' (now: '+ST.group.members.map(nmOf).join(', ')+'). The plan lineup is "
  "only used for this application until you confirm.',ok:'Replace group',onOk:()=>{ set(s=>{ s.group.members=planM.slice(); }); toast('Saved group updated'); }})}>Save this lineup as my "
  'group</button>`}</div>`}</div>',
  1),
 ('rep',
  '<button class="btn p" style="margin-top:22px" onClick=${send}>Send application</button>',
  '<button class="btn p" style="margin-top:22px" disabled=${sent} onClick=${send}>${sent?\'Sending…\':\'Send application\'}</button>',
  1),
 ('rep', 'function approveApp(){\n  set(s=>{ if(!s.app) s.app={', "function approveApp(){\n  if(ST.app&&ST.app.status==='approved'&&ST.contract) return;\n  set(s=>{ if(!s.app) s.app={", 1),
 ('rep',
  "s.group.members.filter(x=>x!=='me').forEach(m=>sg[m]=false); s.contract={lid:s.app.lid,sign:sg,done:false};",
  "(s.app.members||s.group.members).filter(x=>x!=='me').forEach(m=>sg[m]=false); s.contract={lid:s.app.lid,sign:sg,done:false};",
  1),
 ('rep',
  '<button class="btn s" onClick=${()=>{switchRole(\'landlord\');set(s=>{s.stack.landlord=[{id:\'L0\'},{id:\'L2\'},{id:\'L2.1\',p:{id:\'a1\'}}]});toast(\'You are now in the landlord view\');}}>See '
  'it as the landlord</button><button class="btn g" onClick=${()=>{approveApp();toast(\'Serik accepted your application\');}}>Demo: skip to landlord approval</button>',
  '<button class="btn s" onClick=${()=>{ if(Date.now()-LAST_APP_SENT<900) return; '
  "switchRole('landlord');set(s=>{s.stack.landlord=[{id:'L0'},{id:'L2'},{id:'L2.1',p:{id:'a1'}}]});toast('You are now in the landlord view');}}>See it as the landlord</button><button "
  'class="btn g" onClick=${()=>{ if(Date.now()-LAST_APP_SENT<900||(ST.app&&ST.app.status===\'approved\')) return; approveApp();toast(\'Serik accepted your application\');}}>Demo: skip to landlord '
  'approval</button>',
  1),
 ('rep',
  "  const [txt,setTxt]=useState(''); const box=useRef(); const chat=ST.aiChat||[]; const busy=chat.some(m=>m.loading);\n"
  '  useEffect(()=>{ if(box.current) box.current.scrollTop=box.current.scrollHeight; });',
  "  const [txt,setTxt]=useState(''); const box=useRef(); const chat=ST.aiChat||[]; const busy=chat.some(m=>m.loading);\n"
  "  const sig=chat.length+':'+(chat.length&&chat[chat.length-1].loading?1:0);\n"
  '  useEffect(()=>{ if(box.current) box.current.scrollTop=chat.length?box.current.scrollHeight:0; },[sig]);',
  1),
 ('rep',
  "const k=cur().p?.id||'group'; const msgs=ST.chats[k]||[]; const [txt,setTxt]=useState(''); const box=useRef();\n"
  '  useEffect(()=>{ if(box.current) box.current.scrollTop=box.current.scrollHeight; });',
  "const k=cur().p?.id||'group'; const msgs=ST.chats[k]||[]; const [txt,setTxt]=useState(''); const box=useRef();\n"
  '  useEffect(()=>{ if(box.current) box.current.scrollTop=box.current.scrollHeight; },[msgs.length]);',
  1),
 ('rep',
  '<button class="btn s" onClick=${()=>toast(\'Support chat opened. Average reply: 10 minutes.\')}>Chat with support</button>',
  '<button class="btn s" onClick=${()=>sheet(\'support\')}>Chat with support</button>',
  1),
 ('rep',
  "['upload','Download my data','A ZIP archive by email within 24 h',()=>toast('Request received. The archive will arrive by email.')]",
  "['upload','Download my data','A JSON file with your sample data, saved on this device',downloadMyData]",
  1),
 ('rep',
  '<button class="iconbtn" aria-label="Notifications" onClick=${()=>nav(\'M2.1\')}>${Ic(\'bell\')}${ST.notifs.some(n=>!n.read)&&html`<span class="dot"></span>`}</button>`}<${Av} '
  "id=${ST.role==='student'?'me':'serik'} size=${38}/>",
  '<button class="iconbtn" aria-label=${c.id===\'M2.1\'?\'Notification settings\':\'Notifications\'} '
  "onClick=${()=>nav(c.id==='M2.1'?'M2.2':'M2.1')}>${Ic(c.id==='M2.1'?'sliders':'bell')}${c.id!=='M2.1'&&ST.notifs.some(n=>!n.read)&&html`<span "
  'class="dot"></span>`}</button>`}${ST.role===\'student\'?html`<button class="wtop-me" aria-label="Open my profile" onClick=${()=>nav(\'S7\')}><${Av} id="me" size=${38}/></button>`:html`<${Av} '
  'id="serik" size=${38}/>`}',
  1),
 ('rep', "onClick=${()=>id!=='me'&&sheet('profile',{id})}><${Av} id=${id} size=${54}/>", "onClick=${()=>id==='me'?nav('S7'):sheet('profile',{id})}><${Av} id=${id} size=${54}/>", 1),
 ('rep',
  '<button class="iconbtn" aria-label="Notifications" onClick=${()=>toast(\'2 new applications, 1 viewing today\')}>',
  '<button class="iconbtn" aria-label="Notifications: 2 new applications, 1 viewing today" onClick=${()=>nav(\'L2\')}>',
  1),
 ('rep',
  '<button style="color:var(--peri)" onClick=${()=>addTo(r,[{src:room(...sample[r]),name:\'sample\'}])}>Use sample photo</button>',
  '<button class="tt" style="color:var(--peri)" onClick=${()=>addTo(r,[{src:room(...sample[r]),name:\'sample\'}])}>Use sample photo</button>',
  1),
 ('rep', '<button class="btn s" onClick=${()=>set(s=>{s.swiped={}})}>Start over</button>', '<button class="btn s" onClick=${moreDeck}>Show more people</button>', 1),
 ('rep',
  '<div class="h1">You have seen everyone nearby</div><p>New students join every day. Change filters or check your matches.</p>',
  '<div class="h1">You have seen everyone nearby</div><p>That is everyone in this sample. Tap “Show more people” to go through them again with the order shaped by your likes, or check your '
  'matches.</p>',
  1),
 ('reg',
  'function pickMates(o,me,n){',
  'function planRules(G,o){',
  'function pickMates(o,me,n){\n'
  '  if(n<2) return [];\n'
  "  const grp=ST.group.members.filter(x=>x!=='me'&&PEOPLE[x]);\n"
  '  let pool=matePool(o);\n'
  '  const sel=[]; const sc=(a,b)=>score(a,b);\n'
  "  const T=String(o.text||'').toLowerCase();\n"
  '  const wantTidy=(o.clean>=4)||/tidy|clean|чист|аккуратн|порядок/.test(T), chill=!wantTidy&&/relax|chill|messy|не парюсь|расслаб/.test(T);\n'
  '  const cue=p=>{ let v=0;\n'
  '    if(o.sleep===0) v+=p.sleep===0?9:p.sleep===2?-9:0; else if(o.sleep===2) v+=p.sleep===2?9:p.sleep===0?-9:0;\n'
  '    if(o.guests===0) v+=p.guests===0?8:p.guests===2?-8:0; else if(o.guests===2) v+=p.guests===2?8:p.guests===0?-6:0;\n'
  '    if(wantTidy) v+=p.clean>=4?7:p.clean<=2?-8:0; else if(chill) v+=p.clean<=3?5:0;\n'
  '    return v; };\n'
  '  const hasCue=o.sleep!=null||o.guests!=null||wantTidy||chill;\n'
  "  const jit=id=>{ if(hasCue) return 0; let h=0; const s=T+'|'+id; for(let i=0;i<s.length;i++) h=(h*31+s.charCodeAt(i))>>>0; return (h%700)/100-3.5; };\n"
  '  while(sel.length<n-1&&pool.length){\n'
  '    let best=null,bv=-1e9;\n'
  '    for(const id of pool){ const p=PEOPLE[id]; let v=sc(me,p); if(sel.length) v=(v+sel.reduce((a,s)=>a+sc(PEOPLE[s],p),0)/sel.length)/2; if(o.uni&&p.uni===o.uni) v+=6; '
  "if(grp.includes(id)&&o.people===ST.group.members.length) v+=9; if(o.smoke==='no'&&p.smoke==='outside') v-=6; v+=cue(p)+jit(id); if(v>bv){ bv=v; best=id; } }\n"
  '    sel.push(best); pool=pool.filter(x=>x!==best);\n'
  '  }\n'
  '  return sel;\n'
  '}\n'),
 ('rep', 'font:600 9.5px Onest,sans-serif', 'font:600 11.5px Golos Text,sans-serif', 1),
 ('rep', 'opacity=".55" font-size="10" font-weight="700" letter-spacing=".6"', 'opacity=".7" font-size="11.5" font-weight="700" letter-spacing=".4"', 2)]
CSS='/* v4-X2 */\nhtml.cn-lock-t,html.cn-lock-t body{overflow:hidden}\n.t3{overscroll-behavior:contain;touch-action:none}\n.t3:focus{outline:none}\n.pl2 i{transform:translate(calc(-50% + var(--ox,0px)),calc(-125% + var(--oy,0px))) scale(var(--lz,1))}\n.pl2.best i{transform:translate(calc(-50% + var(--ox,0px)),calc(-125% + var(--oy,0px))) scale(var(--lz,1))}\n.pl2.aitu i{transform:translate(calc(-50% + var(--ox,0px)),calc(45% + var(--oy,0px))) scale(var(--lz,1))}\n.pl2.cn-hid i{opacity:0!important}\n.cn-lineup{margin-top:12px;padding-top:12px;border-top:1px solid var(--line)}\n.cn-lineup p{margin:0 0 10px;font-size:14px;line-height:1.45}\n.cn-lineup .btns{display:flex;gap:8px;flex-wrap:wrap}\n.cn-lineup .btn[aria-pressed=true]{border-color:var(--peri);background:color-mix(in srgb,var(--peri) 16%,transparent)}\n.cn-lk{display:block;margin-top:8px;min-height:44px;color:var(--peri);font-weight:600;font-size:14px;text-align:left}\n.wtop-me{border-radius:50%;flex:none;display:inline-flex}\n.wtop-me:focus-visible{outline:3px solid var(--peri);outline-offset:2px}\n.cn-sup{display:flex;flex-direction:column;gap:8px;max-height:44vh;overflow:auto;margin:12px 0}\n.cn-sup-m{max-width:86%;padding:9px 12px;border-radius:14px;background:var(--s2);font-size:14px;line-height:1.4}\n.cn-sup-m.me{align-self:flex-end;background:var(--primary);color:var(--on-primary)}\n.cn-sup-in{display:flex;gap:8px}.cn-sup-in .inp{flex:1;min-width:0}.cn-sup-in .btn{flex:none;width:auto;padding:0 18px}\n.tt{display:inline-flex;align-items:center;justify-content:flex-end}\n@media (max-width:700px),(pointer:coarse){\n  .tt{min-width:44px;min-height:44px;padding:0 4px}\n  .field button[aria-label$="password"]{position:absolute!important;right:2px!important;top:2px!important;width:44px;height:44px;display:grid;place-items:center;padding:0}\n  .lcard-open{display:flex;align-items:center;width:100%;min-height:44px;margin-top:0!important}\n  .switch{width:52px;height:44px;background:none!important}\n  .switch::before{inset:8px 3px;border-radius:14px;background:var(--line-ui);transition:background .2s}\n  .switch.on::before{background:var(--mint)}\n  .switch::after{top:11px;left:6px}\n  .switch.on::after{transform:translateX(18px)}\n}\n@media (max-width:640px){\n  .pc-cta{flex-wrap:nowrap;gap:8px;padding:6px 0 0}\n  .pc-cta .btn{flex:1 1 0;min-width:0;height:44px;min-height:44px;padding:0 8px;font-size:14px;gap:6px}\n}\n'
JS='/* Campus Nest v4-X2: presenter layers, tour focus/scroll lock, honest presenter texts, application lineup, misc UI actions */\nlet PRES_SHEET=null, LAST_PLAN_SEND=0, LAST_APP_SENT=0;\nconst CN_HOVER=()=>!!(window.matchMedia&&matchMedia(\'(hover:hover) and (pointer:fine)\').matches);\nconst presT=S=>typeof S.t===\'function\'?S.t():S.t;\nconst presC=S=>typeof S.c===\'function\'?S.c():S.c;\n/* is the user typing / operating a control that owns the arrow keys? */\nfunction presTyping(t){\n  if(!t||!t.tagName) return false; const g=t.tagName;\n  if(g===\'TEXTAREA\'||g===\'SELECT\'||t.isContentEditable) return true;\n  if(g===\'INPUT\') return ![\'button\',\'checkbox\',\'submit\',\'reset\',\'image\'].includes((t.type||\'\').toLowerCase());\n  return !!(t.closest&&t.closest(\'[contenteditable="true"],[role="slider"],[role="textbox"]\'));\n}\n/* topmost layer that must get Esc / arrows before the presenter */\nfunction presLayer(){\n  if(ST.tour) return \'tour\'; if(ST.ext) return \'ext\'; if(ST.lb) return \'lb\';\n  if(ST.sheet&&!(PRES_SHEET&&ST.sheet===PRES_SHEET)) return \'sheet\';\n  if(document.querySelector(\'.sb-pop\')) return \'pop\';\n  return null;\n}\n/* remember the last control the user pressed, so focus can return to it when the tour closes */\ndocument.addEventListener(\'pointerdown\',e=>{ const b=e.target&&e.target.closest&&e.target.closest(\'button,a[href],[tabindex]\'); if(b&&!b.closest(\'.t3\')) window.__cnLastBtn=b; },true);\n/* 3D tour: lock page scroll, trap focus, return focus on close. Returns the cleanup function. */\nfunction tourOpen(){\n  const de=document.documentElement; de.classList.add(\'cn-lock-t\');\n  let prev=document.activeElement; if(!prev||prev===document.body||(prev.closest&&prev.closest(\'.t3\'))) prev=window.__cnLastBtn||null;\n  const root=document.querySelector(\'.t3\'), x=root&&root.querySelector(\'.t3-x\');\n  if(x){ try{ x.focus({preventScroll:true}); }catch(e){ x.focus(); } }\n  const trap=e=>{\n    if(e.key!==\'Tab\') return; const r=document.querySelector(\'.t3\'); if(!r) return;\n    const f=[...r.querySelectorAll(\'button:not([disabled]),[tabindex="0"]\')].filter(n=>n.offsetParent!==null||n===document.activeElement); if(!f.length) return;\n    const a=f[0], z=f[f.length-1], c=document.activeElement;\n    if(!r.contains(c)){ e.preventDefault(); a.focus(); }\n    else if(e.shiftKey&&c===a){ e.preventDefault(); z.focus(); }\n    else if(!e.shiftKey&&c===z){ e.preventDefault(); a.focus(); }\n  };\n  document.addEventListener(\'keydown\',trap,true);\n  return()=>{ de.classList.remove(\'cn-lock-t\'); document.removeEventListener(\'keydown\',trap,true); if(prev&&prev.focus&&document.contains(prev)){ try{ prev.focus({preventScroll:true}); }catch(e){ prev.focus(); } } };\n}\nfunction trustAvgOf(ids){ const TR={ali:74,mira:70,dana:73,aigerim:71,timur:69,aliya:72,nurlan:66,zhanel:68,arman:62}; return Math.min(99,Math.round((ST.trust.score+ids.filter(x=>x!==\'me\').reduce((a,x)=>a+(TR[x]||68),0))/ids.length)); }\n/* Privacy Center: a real file with the sample data of this prototype */\nfunction downloadMyData(){\n  let json; try{\n    const d={note:\'Sample data from the Campus Nest prototype. Nothing here is real.\',exported:new Date().toISOString().slice(0,10),\n      profile:ST.profile||null,lifestyle:ST.me||null,group:{name:ST.group.name,members:ST.group.members},matches:ST.matches,\n      saved:Object.keys(ST.saved||{}).filter(k=>ST.saved[k]),swipes:ST.swiped||{},application:ST.app||null,trustScore:ST.trust&&ST.trust.score};\n    json=JSON.stringify(d,null,2);\n  }catch(e){ toast(\'Could not build the file.\'); return; }\n  try{ const u=URL.createObjectURL(new Blob([json],{type:\'application/json\'})); const a=document.createElement(\'a\'); a.href=u; a.download=\'campus-nest-my-data.json\'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(u),2000); toast(\'Saved campus-nest-my-data.json (sample data)\'); }\n  catch(e){ toast(\'Your browser blocked the download.\'); }\n}\n/* Help: a small prototype support chat with canned answers */\nconst SUP_ANS=[[/deposit|escrow|залог|депозит/i,\'In this prototype the deposit is simulated. In the planned flow it sits in escrow and is released after the 3-day check-in window, unless you open a dispute.\'],[/document|passport|id\\b|документ/i,\'Documents are seen only by you and a moderator. Landlords see your Trust Score, never the files.\'],[/ai\\b|match|ии|нейро/i,\'Scores are a formula; the AI explains them and, in AI Home Plan, picks from candidates that the rules allow. Without AI the rules do the same job.\'],[/pay|cash|outside|вне приложения|наличн/i,\'Never pay outside the app. Report the chat with the flag button.\']];\nSHEETS.support=()=>{\n  const [msgs,setMsgs]=useState([{f:\'them\',t:\'Hi! This is a demo support chat. Ask about deposits, documents, AI or payments. Answers are canned and nobody is connected in this prototype.\'}]); const [txt,setTxt]=useState(\'\'); const box=useRef();\n  useEffect(()=>{ if(box.current) box.current.scrollTop=box.current.scrollHeight; },[msgs.length]);\n  const send=()=>{ const t=txt.trim(); if(!t) return; setTxt(\'\'); setMsgs(m=>[...m,{f:\'me\',t}]); const a=(SUP_ANS.find(([re])=>re.test(t))||[0,\'Thanks. In the real product an agent would reply here within about 10 minutes. In this prototype nobody is connected, so try one of the keywords: deposit, documents, AI, payments.\'])[1]; setTimeout(()=>setMsgs(m=>[...m,{f:\'them\',t:a}]),500); };\n  return html`<div class="h1">Support chat</div><div class="cn-sup" ref=${box} role="log" aria-live="polite">${msgs.map(m=>html`<div class=${\'cn-sup-m \'+m.f}>${m.t}</div>`)}</div>\n    <div class="cn-sup-in"><input class="inp" aria-label="Message to support" placeholder="Type a message" maxlength="200" value=${txt} onInput=${e=>setTxt(e.target.value)} onKeyDown=${e=>{ if(e.key===\'Enter\') send(); }}/><button class="btn p" onClick=${send}>Send</button></div>`;\n};\nSHEET_NAMES.support=\'Support chat\';\n/* swipe deck: go round again with the order shaped by what you liked */\nfunction moreDeck(){\n  const ids=Object.keys(PEOPLE).filter(id=>id!==\'me\'&&!ST.group.members.includes(id)&&!ST.matches.includes(id));\n  const r=(ST.deckRound||0)+1, k=ids.length?r%ids.length:0;\n  const sorted=ids.slice().sort((a,b)=>score(ST.me,PEOPLE[b])-score(ST.me,PEOPLE[a]));\n  set(s=>{ s.deckRound=r; s.deck=[...sorted.slice(k),...sorted.slice(0,k)]; s.swiped={}; });\n  toast(\'Showing more people, best fits first\');\n}\n'
s=open(SRC,encoding='utf-8').read()
for op in OPS:
    if op[0]=='rep':
        _,old,new,cnt=op
        assert s.count(old)==cnt, ('rep count',s.count(old),cnt,old[:90])
        s=s.replace(old,new)
    else:
        _,a,b,new=op
        i=s.index(a); assert s.count(a)==1,('reg start',a[:60]); j=s.index(b,i+len(a)); assert j>i
        s=s[:i]+new+s[j:]
assert s.count('</head>')==1
s=s.replace('</head>','<style id="cn-v4-x2">\n'+CSS+'</style>\n</head>')
k=s.rindex('<script>'); assert 'render(' in s[k:]
s=s[:k]+'<script id="cn-v4-x2-js">\n'+JS+'</script>\n'+s[k:]
open(DST,'w',encoding='utf-8').write(s)
print('patched',DST,len(s))
