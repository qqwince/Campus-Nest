import sys, asyncio
from playwright.async_api import async_playwright
async def main(path, hashv=''):
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
        for w,h in [(1280,800),(390,844)]:
            pg = await b.new_page(viewport={'width':w,'height':h}); errs=[]
            pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type=='error' else None)
            await pg.goto('file://'+path+hashv); await pg.wait_for_timeout(1500)
            await pg.screenshot(path=f'{path}.{w}.png'); print(w, 'errors:', [e for e in errs if 'fonts.g' not in e and 'ERR_' not in e])
        await b.close()
asyncio.run(main(sys.argv[1], sys.argv[2] if len(sys.argv)>2 else ''))
