import asyncio, sys, json
sys.path.insert(0,'/tmp/cn/d_tools')
from lib import *
async def run_plan(pg, mode, wait=800, phrase=None):
    await pg.evaluate("m=>{window.__calls=[]; if(window.__mock) window.__mock.mode=m;}", mode)
    await pg.evaluate("(t)=>startPlan(t||PLAN_PHRASE,{overlay:true})", phrase)
    await pg.wait_for_timeout(wait)
    await pg.evaluate("skipPlan()")
    await pg.wait_for_timeout(400)
    return await pg.evaluate("()=>{const P=ST.plan; const D=P.dec||{}; return {status:D.status,reason:D.reason,parts:D.parts,issues:D.issues,override:D.override,flat:P.plan.best&&P.plan.best.l.id,top:P.plan.ranked[0].l.id,mates:P.plan.mates,rules:P.plan.rules.map(r=>r.t),letter:P.letter.slice(0,80),checks:(D.checks||[]).map(c=>(c.ok?'+':'-')+c.t),busy:P.busy,phase:P.phase,meta:D.meta,last:ST.ai.last,calls:window.__calls.map(c=>c.task+':'+c.len)}}")
async def main():
    async with async_playwright() as p:
        b,pg,errs=await start(p)
        await load(pg)
        for mode in sys.argv[1:] or ['valid']:
            r=await run_plan(pg,mode); print(mode, json.dumps(r,ensure_ascii=False,indent=1))
        await pg.screenshot(path='/tmp/cn/d_tools/s_valid.png')
        print(clean(errs))
        await b.close()
if __name__=="__main__": asyncio.run(main())
