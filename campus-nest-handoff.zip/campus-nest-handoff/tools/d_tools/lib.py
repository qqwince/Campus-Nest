import asyncio, json
from playwright.async_api import async_playwright
PATH='file://'+__import__('os').environ.get('APP','/ABS/PATH/TO/index.html')
MOCK = r"""
(()=>{
window.__calls=[]; window.__mock={mode:'valid',meta:{provider:'gemini',model:'gemini-2.5-flash',ms:900}};
const grab=(p,re)=>{ const m=p.match(re); return m?JSON.parse(m[1]):[]; };
PROVIDER={name:'Cloudflare AI',json:async(task,p,sig,box)=>{
  const M=window.__mock; window.__calls.push({task,len:p.length,head:p.slice(0,45),p});
  if(M.mode==='hang') return new Promise(()=>{});
  if(M.mode==='429') throw {code:'rate_limited'};
  if(M.mode==='403') throw {code:'not_granted'};
  if(M.mode==='net') throw {code:'network'};
  if(M.mode==='nonjson') throw {code:'invalid_json'};
  if(task==='ping'){ if(M.ping==='fail') throw {code:'upstream_error'}; if(box) box.meta=M.meta; return {ok:true}; }
  if(box) box.meta=M.meta;
  if(task==='apply') return {message:'Hello! We are friendly students and would love to rent this flat for ten months. Could we arrange a viewing this week? Thank you very much!'};
  if(task!=='plan') return {};
  const flats=grab(p,/FLATS \([^)]*\): (\[.*\])\n/), ppl=grab(p,/PEOPLE \([^)]*\): (\[.*\])\n/);
  const n=(p.match(/"students":(\d+)/)||[0,2])[1]*1;
  const r={flat:flats[0].id,backups:flats.slice(1,3).map(f=>f.id),mates:ppl.slice(0,n-1).map(x=>x.id),why:'Gemini picked this flat because it fits the budget with a margin and has a verified landlord. The roommates keep similar sleep and tidiness.',rejected:flats.slice(1,3).map(f=>({id:f.id,why:'Less margin on budget than the chosen flat'})),mate_notes:Object.fromEntries(ppl.slice(0,n-1).map(x=>[x.id,'Matches your tidiness and sleep timing.'])),rules:[{t:'Quiet hours from 23:00 on weekdays.',why:'Sleep times differ in the group.'},{t:'Weekly cleaning rota with fixed zones.',why:'Tidiness ranges from 3 to 5.'},{t:'The cat owner cleans the tray daily.',why:'A cat lives in the flat.'}],letter:'Hello {landlord}! We are {names}, students at AITU. We would like to rent your flat for 10 months from 1 September. Together we can pay the rent and utilities on time, and none of us smokes. Could we book a viewing this week? Thank you!'};
  if(M.mode==='override'){ r.flat=flats[1].id; r.backups=[flats[0].id,(flats[2]||flats[0]).id]; r.why='I chose the cheaper flat with a verified landlord, which leaves a safety margin in the budget. The formula top costs more.'; }
  if(M.mode==='fakeid'){ r.flat='l99'; r.mates=['p99'].concat(r.mates.slice(1)); }
  if(M.mode==='petbreak'){ r.flat='l8'; }
  if(M.mode==='garbage') return {foo:1,flat:42,mates:'x',rules:'no'};
  if(M.mode==='badletter') r.letter='Hello! Call us on +7 701 123 45 67 or see http://x.ru';
  if(M.mode==='2rules') r.rules=r.rules.slice(0,2);
  if(M.mode==='wrongmates') r.mates=r.mates.slice(0,1);
  return r; }};
ST.ai.health={ok:true,gemini:true,workersAi:true,version:'3'}; set(s=>{ s.ai.mode='live'; s.ai.last=null; s.ai.ping=null; });
aiBlockedUntil=0;
})()
"""
async def start(p, w=1280, h=800):
    b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
    pg = await b.new_page(viewport={'width':w,'height':h}); errs=[]
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type=='error' else None)
    return b, pg, errs
async def load(pg, hashv='', mock=True):
    await pg.goto(PATH+hashv); await pg.wait_for_timeout(700)
    if mock: await pg.evaluate(MOCK)
def clean(errs): return [e for e in errs if 'fonts.g' not in e and 'ERR_' not in e]
