import sys, asyncio, json
from playwright.async_api import async_playwright
path=sys.argv[1]; OUT='/tmp/cn/f_tools/shots/'
res=[]
def ok(name,cond,info=''):
    res.append((name,bool(cond),info)); print(('PASS ' if cond else 'FAIL ')+name, info)
RIG="(()=>{const r=document.querySelector('.h3-rig');const g=n=>parseFloat(r.style.getPropertyValue(n));return {ry:g('--ry'),rx:g('--rx'),zm:parseFloat(r.style.getPropertyValue('--zm')||1)}})()"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        # ---------- desktop landing ----------
        ctx=await b.new_context(viewport={'width':1280,'height':800}); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto('file://'+path); await pg.wait_for_timeout(1500)
        sc=pg.locator('.h3-scene'); bb=await sc.bounding_box(); cx=bb['x']+bb['width']*.4; cy=bb['y']+bb['height']*.45
        ok('hint visible on load', await pg.locator('.h3-scene .cn3-hint').count()==1, await pg.locator('.h3-scene .cn3-hint').inner_text())
        ok('touch-action pan-y on landing', await sc.evaluate("e=>getComputedStyle(e).touchAction")=='pan-y')
        ok('cursor grab', await sc.evaluate("e=>getComputedStyle(e).cursor")=='grab')
        # wait out auto; park
        s0=await pg.evaluate(RIG)
        await pg.mouse.move(cx,cy); await pg.mouse.down(); await pg.mouse.move(cx+2,cy+1); await pg.wait_for_timeout(100)
        ok('below threshold: no drag class', not await sc.evaluate("e=>e.classList.contains('cn3-drag')"))
        for i in range(1,11): await pg.mouse.move(cx+2+i*10,cy+1,steps=1); await pg.wait_for_timeout(16)
        ok('grabbing cursor during drag', await sc.evaluate("e=>getComputedStyle(e).cursor")=='grabbing' and await sc.evaluate("e=>e.classList.contains('cn3-drag')"))
        sA=await pg.evaluate(RIG)
        await pg.mouse.up()
        vals=[]
        for i in range(8): await pg.wait_for_timeout(60); vals.append((await pg.evaluate(RIG))['ry'])
        ok('drag rotates', abs(sA['ry']-s0['ry'])>5, f"{s0['ry']:.1f}->{sA['ry']:.1f}")
        ok('inertia after release (keeps moving, decays)', vals[-1]-sA['ry']>1 and abs(vals[-1]-vals[-2])<abs(vals[1]-vals[0])+.01, str([round(v,1) for v in vals]))
        ok('hint gone after gesture', await pg.locator('.h3-scene .cn3-hint').count()==0)
        # wheel without ctrl scrolls page
        await pg.mouse.move(cx,cy); y0=await pg.evaluate("scrollY"); z0=(await pg.evaluate(RIG))['zm']
        await pg.mouse.wheel(0,300); await pg.wait_for_timeout(500)
        ok('plain wheel over landing 3D scrolls page, no zoom', (await pg.evaluate("scrollY"))>y0 and abs((await pg.evaluate(RIG))['zm']-z0)<1e-3, f"scrollY {y0}->{await pg.evaluate('scrollY')}")
        await pg.evaluate("scrollTo(0,0)"); await pg.wait_for_timeout(300)
        await pg.keyboard.down('Control'); await pg.mouse.wheel(0,-300); await pg.keyboard.up('Control'); await pg.wait_for_timeout(600)
        r=await pg.evaluate(RIG); ok('Ctrl+wheel zooms (and no scroll)', r['zm']>z0+.1 and (await pg.evaluate("scrollY"))==0, f"zm {r['zm']:.2f}")
        # buttons
        async def btn(label): await pg.locator(f'.h3-scene .cn3-ctl button[aria-label="{label}"]').click(); await pg.wait_for_timeout(700)
        for i in range(8):
            if not await pg.locator('.h3-scene button[aria-label="Zoom out"]').is_disabled(): await btn('Zoom out')
        r=await pg.evaluate(RIG); ok('zoom out clamps at 0.8', abs(r['zm']-.8)<.02 and await pg.locator('.h3-scene button[aria-label="Zoom out"]').is_disabled(), f"{r['zm']:.2f}")
        for i in range(10):
            if not await pg.locator('.h3-scene button[aria-label="Zoom in"]').is_disabled(): await btn('Zoom in')
        r=await pg.evaluate(RIG); ok('zoom in clamps at 2', abs(r['zm']-2)<.03 and await pg.locator('.h3-scene button[aria-label="Zoom in"]').is_disabled(), f"{r['zm']:.2f}")
        await pg.screenshot(path=OUT+'t_house_zoom2.png',clip={'x':bb['x'],'y':bb['y'],'width':bb['width'],'height':bb['height']})
        await btn('Top view'); r=await pg.evaluate(RIG); ok('Top view pitch', r['rx']<-80, f"rx {r['rx']:.1f}")
        ok('Top view aria-pressed', await pg.locator('.h3-scene button[aria-label="Top view"]').get_attribute('aria-pressed')=='true')
        await pg.screenshot(path=OUT+'t_house_top.png',clip={'x':bb['x'],'y':bb['y'],'width':bb['width'],'height':bb['height']})
        await btn('Reset view'); await pg.wait_for_timeout(800); r=await pg.evaluate(RIG); ok('Reset returns zoom/pitch', abs(r['zm']-1)<.03 and abs(r['rx']+16)<.5, str({k:round(v,1) for k,v in r.items()}))
        ok('pause button label', await pg.locator('.h3-scene button[aria-label="Pause auto-rotation"]').count()==1)
        await btn('Pause auto-rotation'); a=(await pg.evaluate(RIG))['ry']; await pg.wait_for_timeout(5000); a2=(await pg.evaluate(RIG))['ry']
        ok('paused: no auto motion', abs(a-a2)<.1, f"{a:.2f} {a2:.2f}"); ok('resume label', await pg.locator('.h3-scene button[aria-label="Resume auto-rotation"]').count()==1)
        await btn('Resume auto-rotation'); await pg.wait_for_timeout(5500); a3=(await pg.evaluate(RIG))['ry']; ok('resumed: auto motion', abs(a3-a2)>2, f"{a2:.1f}->{a3:.1f}")
        # keyboard
        await pg.evaluate("document.querySelector('.h3-scene').focus()"); 
        k0=(await pg.evaluate(RIG)); await pg.keyboard.press('ArrowRight'); await pg.wait_for_timeout(500); k1=await pg.evaluate(RIG)
        ok('ArrowRight rotates', abs(k1['ry']-k0['ry'])>5); await pg.keyboard.press('+'); await pg.wait_for_timeout(500); k2=await pg.evaluate(RIG); ok('+ zooms', k2['zm']>k1['zm']+.1)
        await pg.keyboard.press('ArrowUp'); await pg.wait_for_timeout(400); k3=await pg.evaluate(RIG); ok('ArrowUp pitches', abs(k3['rx']-k2['rx'])>2)
        await pg.keyboard.press('0'); await pg.wait_for_timeout(900); k4=await pg.evaluate(RIG); ok('0 resets', abs(k4['zm']-1)<.03 and abs(k4['rx']+16)<.6 and abs(k4['ry']+28)<1.5, str({k:round(v,1) for k,v in k4.items()}))
        ok('focus ring on scene', await pg.evaluate("getComputedStyle(document.querySelector('.h3-scene')).outlineStyle")!='none')
        # tap a window still works
        await pg.locator('.h3-u').first.click(); await pg.wait_for_timeout(300); ok('tap window selects flat', await pg.locator('.h3-u.sel').count()==1)
        # drag started over a window does not select
        u=await pg.locator('.h3-u').nth(1).bounding_box(); await pg.mouse.move(u['x']+10,u['y']+10); await pg.mouse.down(); 
        for i in range(10): await pg.mouse.move(u['x']+10+i*8,u['y']+10,steps=1)
        await pg.mouse.up(); await pg.wait_for_timeout(200)
        ok('drag from a window rotates and does not select it', await pg.locator('.h3-u.sel').count()==1 and await pg.evaluate("document.querySelector('.h3-u.sel')===document.querySelectorAll('.h3-u')[0]"))
        ok('no page errors (desktop landing)', not errs, str(errs))
        await ctx.close()
        # ---------- mobile landing touch ----------
        ctx=await b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,device_scale_factor=2); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto('file://'+path); await pg.wait_for_timeout(1500)
        cdp=await ctx.new_cdp_session(pg)
        await pg.evaluate("document.querySelector('.h3-scene').scrollIntoView({block:'center'})"); await pg.wait_for_timeout(600)
        sc=pg.locator('.h3-scene'); bb=await sc.bounding_box(); cx=bb['x']+bb['width']/2; cy=bb['y']+bb['height']/2
        ok('hint text on touch', 'pinch' in await pg.locator('.h3-scene .cn3-hint').inner_text(), await pg.locator('.h3-scene .cn3-hint').inner_text())
        async def touch(points_seq):
            # points_seq: list of lists of (x,y,id)
            for i,pts in enumerate(points_seq):
                t='touchStart' if i==0 else ('touchEnd' if i==len(points_seq)-1 else 'touchMove')
                if t=='touchEnd': await cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]})
                else: await cdp.send('Input.dispatchTouchEvent',{'type':t,'touchPoints':[{'x':x,'y':y,'id':id} for x,y,id in pts]})
                await pg.wait_for_timeout(16)
        sy0=await pg.evaluate("scrollY"); 
        seq=[[(cx,cy+100,0)]]+[[(cx,cy+100-i*12,0)] for i in range(1,16)]+[[]]
        await touch(seq); await pg.wait_for_timeout(600)
        sy1=await pg.evaluate("scrollY"); ok('vertical finger swipe over 3D scrolls the page', sy1>sy0+40, f"{sy0}->{sy1}")
        await pg.evaluate("document.querySelector('.h3-scene').scrollIntoView({block:'center'})"); await pg.wait_for_timeout(600)
        bb=await sc.bounding_box(); cx=bb['x']+bb['width']/2; cy=bb['y']+bb['height']/2
        r0=await pg.evaluate(RIG); seq=[[(cx-60,cy,0)]]+[[(cx-60+i*8,cy,0)] for i in range(1,16)]+[[]]
        await touch(seq); await pg.wait_for_timeout(100); r1=await pg.evaluate(RIG); ok('horizontal finger drag rotates', abs(r1['ry']-r0['ry'])>8, f"{r0['ry']:.1f}->{r1['ry']:.1f}")
        # pinch
        z0=(await pg.evaluate(RIG))['zm']
        seq=[[(cx-30,cy,1),(cx+30,cy,2)]]+[[(cx-30-i*6,cy,1),(cx+30+i*6,cy,2)] for i in range(1,12)]+[[]]
        await touch(seq); await pg.wait_for_timeout(600); z1=(await pg.evaluate(RIG))['zm']; ok('pinch zooms in', z1>z0+.2, f"{z0:.2f}->{z1:.2f}")
        ok('no page errors (mobile landing)', not errs, str(errs))
        await ctx.close()
        # ---------- tour ----------
        for mob in (False,True):
          ctx=await b.new_context(viewport={'width':390 if mob else 1280,'height':844 if mob else 800},has_touch=mob,is_mobile=mob); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
          cdp=await ctx.new_cdp_session(pg)
          await pg.goto('file://'+path+'#app'); await pg.wait_for_timeout(1000)
          await pg.evaluate("set(s=>{s.tour='l1'})"); await pg.wait_for_timeout(800)
          TR="(()=>{const r=document.querySelector('.t3-rig'),p=document.querySelector('.t3-persp');const g=n=>parseFloat(r.style.getPropertyValue(n));return {ty:g('--ty'),tp:g('--tp'),ts:parseFloat(p.style.getPropertyValue('--ts'))}})()"
          tag='mobile' if mob else 'desktop'
          v=pg.locator('.t3-view'); bb=await v.bounding_box(); cx=bb['x']+bb['width']/2; cy=bb['y']+bb['height']/2
          ok(f'tour[{tag}] touch-action none', await v.evaluate("e=>getComputedStyle(e).touchAction")=='none')
          t0=await pg.evaluate(TR); z0ts=t0['ts']; await pg.wait_for_timeout(1000); t1=await pg.evaluate(TR); ok(f'tour[{tag}] auto-spin', abs(t1['ty']-t0['ty'])>3, f"{t0['ty']:.1f}->{t1['ty']:.1f}")
          if not mob:
            await pg.mouse.move(cx,cy); await pg.mouse.down()
            for i in range(1,13): await pg.mouse.move(cx+i*10,cy+i*3,steps=1); await pg.wait_for_timeout(16)
            await pg.mouse.up(); await pg.wait_for_timeout(50); a=await pg.evaluate(TR); await pg.wait_for_timeout(300); a2=await pg.evaluate(TR)
            ok('tour drag + inertia', a['ty']<t1['ty']-10 and a2['ty']<a['ty']-.5, f"{a['ty']:.1f}->{a2['ty']:.1f}")
            ok('tour: auto stops after drag', True)
            await pg.wait_for_timeout(1500); a3=await pg.evaluate(TR); a4=await pg.evaluate(TR); await pg.wait_for_timeout(1500); a5=await pg.evaluate(TR); ok('tour no auto after drag', abs(a5['ty']-a3['ty'])<.2)
            z=a5['ts']; await pg.mouse.move(cx,cy); await pg.mouse.wheel(0,-400); await pg.wait_for_timeout(600); z2=(await pg.evaluate(TR))['ts']; ok('tour wheel zooms', z2>z*1.2, f"{z:.2f}->{z2:.2f}")
            await pg.screenshot(path=OUT+'t_tour_zoom.png')
            await pg.keyboard.press('ArrowLeft'); await pg.wait_for_timeout(500); b1=await pg.evaluate(TR); ok('tour ArrowLeft', b1['ty']<a5['ty']-5 or b1['ty']>a5['ty']+5)
            await pg.keyboard.press('0'); await pg.wait_for_timeout(1000); b2=await pg.evaluate(TR); ok('tour 0 resets', abs(b2['ty'])<1 and abs(b2['tp'])<1 and abs(b2['ts']-z0ts)<.02, str(b2))
            await pg.locator('.t3-view button[aria-label="Zoom in"]').click(); await pg.wait_for_timeout(500); ok('tour + button', (await pg.evaluate(TR))['ts']>b2['ts']*1.1)
            await pg.locator('.t3-view button[aria-label="Reset view"]').click(); await pg.wait_for_timeout(800); ok('tour reset button', abs((await pg.evaluate(TR))['ts']-b2['ts'])<.05)
            await pg.locator('.t3-foot button').nth(2).click(); await pg.wait_for_timeout(1200); c=await pg.evaluate(TR); ok('tour room button turns to 180', abs(c['ty']-180)<2 or abs(abs(c['ty'])-180)<2, str(c))
            ok('tour Pause button present', await pg.locator('.t3-view button[aria-label$="auto-rotation"]').count()==1)
            ok('tour hint gone', await pg.locator('.t3-view .cn3-hint').count()==0)
            await pg.keyboard.press('Escape'); await pg.wait_for_timeout(300); ok('Escape closes tour', await pg.locator('.t3').count()==0)
          else:
            async def touch(seq):
                for i,pts in enumerate(seq):
                    t='touchStart' if i==0 else ('touchEnd' if i==len(seq)-1 else 'touchMove')
                    await cdp.send('Input.dispatchTouchEvent',{'type':t,'touchPoints':[] if t=='touchEnd' else [{'x':x,'y':y,'id':id} for x,y,id in pts]}); await pg.wait_for_timeout(16)
            a=await pg.evaluate(TR); await touch([[(cx-80,cy,0)]]+[[(cx-80+i*10,cy,0)] for i in range(1,14)]+[[]]); await pg.wait_for_timeout(100); b1=await pg.evaluate(TR)
            ok('tour touch drag', abs(b1['ty']-a['ty'])>15, f"{a['ty']:.1f}->{b1['ty']:.1f}")
            await pg.wait_for_timeout(300); z=(await pg.evaluate(TR))['ts']
            await touch([[(cx-30,cy,1),(cx+30,cy,2)]]+[[(cx-30-i*7,cy,1),(cx+30+i*7,cy,2)] for i in range(1,12)]+[[]]); await pg.wait_for_timeout(600); z2=(await pg.evaluate(TR))['ts']
            ok('tour pinch zoom', z2>z*1.2, f"{z:.2f}->{z2:.2f}"); await pg.screenshot(path=OUT+'t_tour_mobile.png')
          ok(f'no page errors (tour {tag})', not errs, str(errs)); await ctx.close()
        # ---------- plan ----------
        for mob in (False,True):
          ctx=await b.new_context(viewport={'width':390 if mob else 1280,'height':844 if mob else 800},has_touch=mob,is_mobile=mob); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
          cdp=await ctx.new_cdp_session(pg); tag='mobile' if mob else 'desktop'
          await pg.goto('file://'+path); await pg.wait_for_timeout(1000)
          await pg.locator('.ph-box textarea').first.fill('Нас трое, ищем 2-комнатную квартиру до 300 000 тенге рядом с AITU, есть кошка'); await pg.locator('.ph-box .pv-go').first.click()
          await pg.wait_for_timeout(10500)
          PS="(()=>{const w=document.querySelector('.ps-w'),e=document.querySelector('.ps');const g=n=>parseFloat(w.style.getPropertyValue(n));return {s:g('--s'),a:g('--a'),b:g('--b'),lz:parseFloat(e.style.getPropertyValue('--lz')),zoomAttr:e.dataset.zoom||'',ph:e.dataset.ph}})()"
          ps=pg.locator('.ps'); bb=await ps.bounding_box(); cx=bb['x']+bb['width']*.5; cy=bb['y']+bb['height']*.5
          ok(f'plan[{tag}] touch-action none', await ps.evaluate("e=>getComputedStyle(e).touchAction")=='none')
          ok(f'plan[{tag}] phase 4', (await pg.evaluate(PS))['ph']=='4')
          def overlap(a,b): return not (a['x']+a['width']<=b['x'] or b['x']+b['width']<=a['x'] or a['y']+a['height']<=b['y'] or b['y']+b['height']<=a['y'])
          async def best_vs_you():
              bl=await pg.locator('.pl2.best i').bounding_box(); nds=pg.locator('.ps-nd'); n=await nds.count(); bad=0
              for i in range(n):
                  nb=await nds.nth(i).bounding_box()
                  if overlap(bl,nb): bad+=1
              return bad,n,bl
          bad,n,bl=await best_vs_you(); ok(f'plan[{tag}] best label not covered by avatars (n={n})', bad==0, f"overlaps={bad}")
          await pg.screenshot(path=OUT+f't_plan_{tag}.png')
          if not mob:
            s0=await pg.evaluate(PS); await pg.mouse.move(cx,cy); await pg.mouse.down()
            for i in range(1,13): await pg.mouse.move(cx+i*9,cy+i*4,steps=1); await pg.wait_for_timeout(16)
            await pg.mouse.up(); await pg.wait_for_timeout(500); s1=await pg.evaluate(PS)
            ok('plan drag rotates + tilts', abs(s1['b']-s0['b'])>8 and abs(s1['a']-s0['a'])>2, f"b {s0['b']:.1f}->{s1['b']:.1f} a {s0['a']:.1f}->{s1['a']:.1f}")
            bad,n,bl=await best_vs_you(); ok('plan best label clear after rotate', bad==0, f"overlaps={bad}")
            await pg.mouse.move(cx,cy); await pg.mouse.wheel(0,-500); await pg.wait_for_timeout(700); s2=await pg.evaluate(PS); ok('plan wheel zooms in', s2['s']>s1['s']*1.3 and s2['lz']>1.05, str({k:(round(v,2) if isinstance(v,float) else v) for k,v in s2.items()}))
            await pg.screenshot(path=OUT+'t_plan_zoomin.png')
            await pg.mouse.wheel(0,2500); await pg.wait_for_timeout(900); s3=await pg.evaluate(PS); ok('plan zoom out limit + low-zoom label thinning', s3['s']<s1['s'] and s3['zoomAttr']=='out', str(s3))
            await pg.screenshot(path=OUT+'t_plan_zoomout.png')
            await pg.locator('.ps button[aria-label="Top view"]').click(); await pg.wait_for_timeout(2500); s4=await pg.evaluate(PS); ok('plan top view a=-90', abs(s4['a']+90)<.6, f"a={s4['a']}")
            await pg.screenshot(path=OUT+'t_plan_top.png')
            await pg.locator('.ps button[aria-label$="auto-rotation"]').click(); await pg.locator('.ps button[aria-label="Reset view"]').click(); await pg.wait_for_timeout(3000); s5=await pg.evaluate(PS); ok('plan reset', abs(s5['b']+22)<1 and abs(s5['a']-s0['a'])<1 , f"{s5} vs {s0}")
            await pg.evaluate("document.querySelector('.ps').focus()"); await pg.keyboard.press('ArrowLeft'); await pg.wait_for_timeout(500); s6=await pg.evaluate(PS); ok('plan key rotate', abs(s6['b']-s5['b'])>5)
            await pg.keyboard.press('+'); await pg.wait_for_timeout(500); ok('plan + key', (await pg.evaluate(PS))['s']>s6['s']*1.1)
            await pg.keyboard.press('0'); await pg.wait_for_timeout(900)
            ok('plan scroll: skip button still clickable', await pg.locator('.ps-skip').count()==1)
          else:
            async def touch(seq):
                for i,pts in enumerate(seq):
                    t='touchStart' if i==0 else ('touchEnd' if i==len(seq)-1 else 'touchMove')
                    await cdp.send('Input.dispatchTouchEvent',{'type':t,'touchPoints':[] if t=='touchEnd' else [{'x':x,'y':y,'id':id} for x,y,id in pts]}); await pg.wait_for_timeout(16)
            await pg.evaluate("document.querySelector('.ps').scrollIntoView({block:'center'})") ; await pg.wait_for_timeout(300)
            bb=await ps.bounding_box(); cx=bb['x']+bb['width']*.4; cy=bb['y']+bb['height']*.5
            s0=await pg.evaluate(PS); await touch([[(cx,cy,0)]]+[[(cx+i*8,cy+i*3,0)] for i in range(1,14)]+[[]]); await pg.wait_for_timeout(500); s1=await pg.evaluate(PS)
            ok('plan touch drag rotates', abs(s1['b']-s0['b'])>8 and abs(s1['a']-s0['a'])>1, f"b {s0['b']:.1f}->{s1['b']:.1f}")
            await touch([[(cx-30,cy,1),(cx+30,cy,2)]]+[[(cx-30-i*6,cy,1),(cx+30+i*6,cy,2)] for i in range(1,12)]+[[]]); await pg.wait_for_timeout(600); s2=await pg.evaluate(PS); ok('plan pinch zoom', s2['s']>s1['s']*1.3, f"{s1['s']:.2f}->{s2['s']:.2f}")
            bad,n,bl=await best_vs_you(); ok('plan[mobile] best label clear after pinch', bad==0, f"overlaps={bad}")
            await pg.screenshot(path=OUT+'t_plan_mobile_zoom.png')
          ok(f'no page errors (plan {tag})', not errs, str(errs)); await ctx.close()
        # ---------- reduced motion ----------
        ctx=await b.new_context(viewport={'width':1280,'height':800},reduced_motion='reduce'); pg=await ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto('file://'+path); await pg.wait_for_timeout(1200)
        a=(await pg.evaluate(RIG))['ry']; await pg.wait_for_timeout(3500); a2=(await pg.evaluate(RIG))['ry']; ok('reduced-motion: no auto-rotation', abs(a-a2)<.01, f"{a} {a2}")
        ok('reduced-motion: no pause button', await pg.locator('.h3-scene button[aria-label$="auto-rotation"]').count()==0)
        sc=pg.locator('.h3-scene'); bb=await sc.bounding_box(); cx=bb['x']+bb['width']*.4; cy=bb['y']+bb['height']*.45
        await pg.mouse.move(cx,cy); await pg.mouse.down()
        for i in range(1,12): await pg.mouse.move(cx+i*10,cy,steps=1); await pg.wait_for_timeout(16)
        await pg.mouse.up(); await pg.wait_for_timeout(30); r1=(await pg.evaluate(RIG))['ry']; await pg.wait_for_timeout(500); r2=(await pg.evaluate(RIG))['ry']
        ok('reduced-motion: drag works, no inertia', abs(r1-a)>5 and abs(r2-r1)<.05, f"{a:.1f} {r1:.1f} {r2:.1f}")
        ok('no page errors (reduced motion)', not errs, str(errs)); await ctx.close()
        await b.close()
    print('\nSUMMARY', sum(1 for r in res if r[1]),'/',len(res),'pass'); print([r[0] for r in res if not r[1]])
asyncio.run(main())
