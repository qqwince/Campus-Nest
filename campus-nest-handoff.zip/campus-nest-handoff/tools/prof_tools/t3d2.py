import asyncio, json
from playwright.async_api import async_playwright
PATH=__import__('os').environ.get('APP','/ABS/PATH/TO/index.html'); SH='/tmp/cn/prof/shots/'
R={}
async def trig(pg): return await pg.evaluate("()=>{const r=document.querySelector('.t3-rig');return r?[parseFloat(r.style.getPropertyValue('--ty')),parseFloat(r.style.getPropertyValue('--tp'))]:null}")
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    for rm in ['no-preference','reduce']:
      ctx=await b.new_context(viewport={'width':1280,'height':800},reduced_motion=rm); pg=await ctx.new_page()
      await pg.goto('file://'+PATH); await pg.wait_for_timeout(1500)
      res=[]
      for k in range(3):
        u=pg.locator('.h3-u:not(.empty)').nth(k); bb=await u.bounding_box()
        x,y=bb['x']+bb['width']/2,bb['y']+bb['height']/2
        at=await pg.evaluate(f"()=>{{const e=document.elementFromPoint({x},{y});return e&&(e.closest('.h3-u')?'unit':e.className)}}")
        await pg.mouse.move(x,y); await pg.wait_for_timeout(50)
        ev=await pg.evaluate("()=>{window.__ev=[];['pointerdown','pointerup','click'].forEach(t=>document.addEventListener(t,e=>window.__ev.push(t+':'+(e.target.className||e.target.tagName)),{capture:true,once:false}));return 1}")
        await pg.mouse.down(); await pg.mouse.up(); await pg.wait_for_timeout(300)
        res.append({'elAtPoint':at,'card':await pg.locator('.h3-card').count(),'events':await pg.evaluate('window.__ev')})
      R['unit_click_'+rm]=res
      await ctx.close()
    pg=await b.new_page(viewport={'width':1280,'height':800}); await pg.goto('file://'+PATH); await pg.wait_for_timeout(1200)
    await pg.evaluate("()=>set(s=>{s.tour='l1'})"); await pg.wait_for_timeout(800)
    await pg.screenshot(path=SH+'3d_tour_1280.png')
    vb=await pg.locator('.t3-view').bounding_box(); vx,vy=vb['x']+vb['width']/2, vb['y']+vb['height']/2
    s0=await trig(pg); await pg.wait_for_timeout(1000); s1=await trig(pg); R['tour_autorotate_1s']=[s0,s1]
    await pg.mouse.move(vx,vy); await pg.mouse.down(); await pg.mouse.move(vx+200,vy+100,steps=10); await pg.wait_for_timeout(500); dd=await trig(pg); await pg.mouse.up(); await pg.wait_for_timeout(1500); de=await trig(pg)
    R['tour_drag_right200_down100']={'during':dd,'after_release_1.5s':de}
    await pg.screenshot(path=SH+'3d_tour_1280_dragged.png')
    y0=await pg.evaluate('scrollY'); await pg.mouse.wheel(0,600); await pg.wait_for_timeout(400); R['tour_wheel']=[y0,await pg.evaluate('scrollY'),await trig(pg)]
    await pg.keyboard.press('ArrowRight'); await pg.wait_for_timeout(500); R['tour_key_right']=await trig(pg)
    await pg.keyboard.press('ArrowUp'); await pg.wait_for_timeout(500); R['tour_key_up']=await trig(pg)
    R['tour_hint']=await pg.locator('.t3-hint').inner_text()
    R['tour_wall_btns']=await pg.locator('.t3-foot button').all_inner_texts()
    R['tour_walls_imgs']=await pg.evaluate("()=>[...document.querySelectorAll('.t3-w img')].map(i=>i.src.slice(0,40))")
    foc=[]
    for i in range(9):
      await pg.keyboard.press('Tab'); foc.append(await pg.evaluate("()=>{const a=document.activeElement;return (a.closest('.t3')?'IN:':'OUT:')+(a.innerText||a.getAttribute('aria-label')||a.tagName).slice(0,25)}"))
    R['tour_tab_order']=foc
    # pressing a room button then reading label
    await pg.locator('.t3-foot button').nth(2).click(); await pg.wait_for_timeout(1200); R['after_room3']=[await trig(pg), await pg.evaluate("()=>[...document.querySelectorAll('.t3-foot button')].map(b=>b.getAttribute('aria-pressed'))")]
    await pg.keyboard.press('Escape'); await pg.wait_for_timeout(300); R['tour_closed_by_esc']=await pg.locator('.t3').count()==0
    # tour from listing page: is there a 3D tour button in S2.3?
    await pg.evaluate("()=>{jump('S2.3'); openView('app');}"); await pg.wait_for_timeout(400)
    R['S23_has_tour_btn']=await pg.locator('button:has-text("3D tour")').count()
    await b.close()
  json.dump(R,open('/tmp/cn/prof/t3d2.json','w'),ensure_ascii=False,indent=1); print(json.dumps(R,ensure_ascii=False,indent=1))
asyncio.run(main())
