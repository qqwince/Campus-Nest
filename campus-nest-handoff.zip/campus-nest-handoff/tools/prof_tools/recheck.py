import sys, asyncio, json
from playwright.async_api import async_playwright
PATH=__import__('os').environ.get('APP','/ABS/PATH/TO/index.html')
W=int(sys.argv[1]); H=844 if W<500 else 800
d=json.load(open(f'/tmp/cn/prof/crawl_{W}_light.json'))
SIG2='''()=>{const b=document.body; let h=0; const t=b.innerHTML+[...document.querySelectorAll('input,textarea,select')].map(e=>e.value+e.checked).join('|'); for(let i=0;i<t.length;i++){h=(h*31+t.charCodeAt(i))|0;} return h}'''
STATE='''()=>JSON.stringify({saved:ST.saved,filters:ST.filters,me:ST.me,ll:ST.ll,notif:ST.notifSet||null})'''
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=await (await b.new_context(viewport={'width':W,'height':H},has_touch=(W<500))).new_page()
    await pg.goto('file://'+PATH); await pg.wait_for_timeout(1200)
    out=[]
    for sid,s in d['screens'].items():
      for r in s['rows']:
        if r['res'] not in ('NONE','toast-only'): continue
        await pg.evaluate('''(sid)=>{ try{presExit()}catch(e){} resetDemo(); jump(sid); openView('app'); }''', sid); await pg.wait_for_timeout(300)
        h0=await pg.evaluate(SIG2); st0=await pg.evaluate(STATE); y0=await pg.evaluate("()=>{const b=document.querySelector('.body,.wbody');return [scrollY,b&&b.scrollTop]}")
        el=(await pg.evaluate_handle(f'()=>[...document.querySelectorAll("button,a,[role=button],input[type=checkbox],select,summary")][{r["i"]}]')).as_element()
        try: await el.click(timeout=1500)
        except Exception as e: out.append([sid,r['txt'],'clickfail']); continue
        await pg.wait_for_timeout(400)
        h1=await pg.evaluate(SIG2); st1=await pg.evaluate(STATE); y1=await pg.evaluate("()=>{const b=document.querySelector('.body,.wbody');return [scrollY,b&&b.scrollTop]}")
        foc=await pg.evaluate("()=>document.activeElement&&(document.activeElement.tagName+':'+(document.activeElement.getAttribute('aria-label')||''))")
        out.append([sid,r['txt'] or r['aria'],r['res'],'HTML-changed' if h0!=h1 else 'HTML-same','STATE-changed' if st0!=st1 else 'state-same', 'scroll' if y0!=y1 else '', foc])
    json.dump(out,open(f'/tmp/cn/prof/recheck_{W}.json','w'),ensure_ascii=False,indent=0)
    for o in out:
      if o[3]=='HTML-same' or o[2]=='toast-only': print(o)
    await b.close()
asyncio.run(main())
