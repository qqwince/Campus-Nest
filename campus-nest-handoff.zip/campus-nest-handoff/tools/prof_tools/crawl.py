import sys, asyncio, json, hashlib
from playwright.async_api import async_playwright
PATH=__import__('os').environ.get('APP','/ABS/PATH/TO/index.html')
W=int(sys.argv[1]); H=844 if W<500 else 800; THEME=sys.argv[2] if len(sys.argv)>2 else 'light'
OUT=f'/tmp/cn/prof/crawl_{W}_{THEME}.json'
SIG='''()=>{const c=cur();return JSON.stringify({v:ST.view,role:ST.role,id:c.id,p:c.p||null,sheet:ST.sheet&&ST.sheet.type,toast:ST.toast,ext:ST.ext?JSON.stringify(ST.ext).slice(0,80):null,lb:!!ST.lb,tour:ST.tour,plan:!!ST.planOpen,hash:location.hash})}'''
BODY='''()=>{const t=document.body.innerText; let h=0; for(let i=0;i<t.length;i++){h=(h*31+t.charCodeAt(i))|0;} return h+':'+t.length+':'+document.querySelectorAll('*').length}'''
LIST='''()=>{const out=[];const els=[...document.querySelectorAll('button,a,[role=button],input[type=checkbox],select,summary')];
 els.forEach((e,i)=>{const r=e.getBoundingClientRect(); const cs=getComputedStyle(e); const vis=r.width>0&&r.height>0&&cs.visibility!=='hidden'&&cs.display!=='none';
  if(!vis) return; out.push({i,tag:e.tagName,txt:(e.innerText||e.getAttribute('aria-label')||e.title||e.value||'').trim().replace(/\\s+/g,' ').slice(0,60),aria:e.getAttribute('aria-label'),dis:!!e.disabled,href:e.getAttribute('href'),inSite:!!e.closest('.sb'),w:Math.round(r.width),h:Math.round(r.height)});});return out;}'''
async def prep(pg,sid):
    await pg.evaluate('''(sid)=>{ try{presExit()}catch(e){} resetDemo(); set(s=>{s.tour=null;}); jump(sid); openView('app'); }''', sid)
    await pg.wait_for_timeout(350)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
        ctx=await b.new_context(viewport={'width':W,'height':H},color_scheme=THEME, has_touch=(W<500))
        pg=await ctx.new_page(); errs=[]; dialogs=[]
        pg.on('pageerror',lambda e: errs.append(('pageerror',str(e)[:300])))
        pg.on('console',lambda m: errs.append(('console',m.text[:300])) if m.type=='error' and 'fonts.g' not in m.text and 'ERR_' not in m.text else None)
        pg.on('dialog',lambda d: (dialogs.append(d.message), asyncio.ensure_future(d.dismiss())))
        popups=[]; ctx.on('page',lambda np: popups.append(np.url))
        await pg.goto('file://'+PATH); await pg.wait_for_timeout(1200)
        screens=await pg.evaluate('Object.keys(SCREENS)')
        res={'screens':{}, 'errors':errs, 'dialogs':dialogs,'popups':popups}
        for sid in screens:
            await prep(pg,sid)
            before_sig=await pg.evaluate(SIG)
            await pg.screenshot(path=f'/tmp/cn/prof/shots/{W}_{THEME}_{sid}.png')
            full=await pg.evaluate('()=>{const b=document.querySelector(".body,.wbody");return b?{sh:b.scrollHeight,ch:b.clientHeight}:null}')
            items=await pg.evaluate(LIST)
            items=[it for it in items if not it['inSite']]
            rows=[]; e0=len(errs)
            for it in items:
                if it['dis']: rows.append({**it,'res':'disabled'}); continue
                await prep(pg,sid)
                s0=await pg.evaluate(SIG); b0=await pg.evaluate(BODY); ne=len(errs)
                try:
                    h=await pg.evaluate_handle(f'()=>[...document.querySelectorAll("button,a,[role=button],input[type=checkbox],select,summary")][{it["i"]}]')
                    el=h.as_element()
                    if el is None: rows.append({**it,'res':'gone'}); continue
                    t=(await el.inner_text()).strip()[:60] if it['tag']!='SELECT' else ''
                    if it['tag']=='SELECT':
                        rows.append({**it,'res':'select'}); continue
                    await el.click(timeout=1500)
                except Exception as ex:
                    rows.append({**it,'res':'clickfail:'+str(ex).split('\n')[0][:120]}); continue
                await pg.wait_for_timeout(450)
                s1=await pg.evaluate(SIG); b1=await pg.evaluate(BODY)
                d0=json.loads(s0); d1=json.loads(s1)
                diff={k:[d0[k],d1[k]] for k in d0 if d0[k]!=d1[k]}
                kind='nav' if ('id' in diff or 'v' in diff or 'role' in diff or 'p' in diff) else 'sheet' if 'sheet' in diff else 'overlay' if ('tour' in diff or 'plan' in diff or 'ext' in diff or 'lb' in diff) else 'toast-only' if list(diff)==['toast'] else 'dom' if b0!=b1 else 'NONE'
                # spinner check
                spin=await pg.evaluate('()=>document.querySelectorAll(".spin,.aix-dots,.sk").length')
                rows.append({**it,'res':kind,'diff':diff,'spin':spin,'newerr':errs[ne:]})
            res['screens'][sid]={'before':before_sig,'scroll':full,'rows':rows}
            print(sid,len(rows),flush=True)
            json.dump(res,open(OUT,'w'),ensure_ascii=False,indent=1)
        await b.close()
asyncio.run(main())
