import json,sys,collections
d=json.load(open(sys.argv[1]))
print('ERRORS',len(d['errors']),d['errors'][:10]); print('DIALOGS',d['dialogs']); print('POPUPS',d['popups'])
cnt=collections.Counter()
for sid,s in d['screens'].items():
  rows=s['rows']; c=collections.Counter(r['res'].split(':')[0] for r in rows); cnt.update(c)
  bad=[r for r in rows if r['res'] in('NONE','toast-only') or r['res'].startswith('clickfail') or r.get('newerr')]
  print(f"\n## {sid} {dict(c)} scroll={s['scroll']}")
  for r in bad:
    print('   ',r['res'][:70],'|',r['txt'] or r['aria'],'|',json.dumps(r.get('diff',{}),ensure_ascii=False)[:160], r.get('newerr') or '')
  small=[ (r['txt'] or r['aria'],r['w'],r['h']) for r in rows if (r['w']<32 or r['h']<32)]
  if small: print('    SMALL:',small[:8])
print(cnt)
