import asyncio, json
from playwright.async_api import async_playwright
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    for W in (390,1280):
      pg=await (await b.new_context(viewport={'width':W,'height':844},has_touch=W<500)).new_page(); await pg.goto('file://'+__import__('os').environ.get('APP','/ABS/PATH/TO/index.html')); await pg.wait_for_timeout(1000)
      ids=await pg.evaluate('Object.keys(SCREENS)')
      for sid in ['landing']+ids:
        if sid=='landing': await pg.evaluate("()=>{resetDemo();}")
        else: await pg.evaluate("(s)=>{resetDemo(); jump(s); openView('app');}",sid)
        await pg.wait_for_timeout(250)
        r=await pg.evaluate("""(W)=>{const o=[];document.querySelectorAll('body *').forEach(e=>{const r=e.getBoundingClientRect(); if(r.width>0&&r.right>W+2&&!e.closest('.t3,.h3-scene,.ps,.cn-confetti,.h3-rig')&&getComputedStyle(e).position!=='fixed') o.push((e.className||e.tagName)+':'+Math.round(r.right))}); 
          const small=[...document.querySelectorAll('button,a')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&(r.height<24||r.width<24)&&!e.closest('.h3-scene')}).map(e=>(e.innerText||e.getAttribute('aria-label')||'').slice(0,20)+'['+Math.round(e.getBoundingClientRect().width)+'x'+Math.round(e.getBoundingClientRect().height)+']');
          const tiny=[...document.querySelectorAll('body *')].filter(e=>e.childNodes.length&&[...e.childNodes].some(n=>n.nodeType==3&&n.textContent.trim())&&parseFloat(getComputedStyle(e).fontSize)<11&&e.getBoundingClientRect().width>0).map(e=>e.textContent.trim().slice(0,20)+'('+getComputedStyle(e).fontSize+')');
          return {sw:document.documentElement.scrollWidth,o:o.slice(0,5),small:small.slice(0,6),tiny:tiny.slice(0,5)}}""",W)
        if r['sw']>W or r['o'] or r['small'] or r['tiny']: print(W,sid,json.dumps(r,ensure_ascii=False))
    await b.close()
asyncio.run(main())
