import asyncio
from playwright.async_api import async_playwright
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=await b.new_page(viewport={'width':1280,'height':800}); await pg.goto('file://'+__import__('os').environ.get('APP','/ABS/PATH/TO/index.html')); await pg.wait_for_timeout(1000)
    await pg.evaluate("()=>set(s=>{s.tour='l1'})"); await pg.wait_for_timeout(500)
    for i in range(4):
      await pg.locator('.t3-foot button').nth(i).click(); await pg.wait_for_timeout(1800)
      # which wall is most frontal: measure center-ness of each wall img
      info=await pg.evaluate("()=>[...document.querySelectorAll('.t3-w')].map((w,k)=>{const r=w.getBoundingClientRect();return [k,Math.round(r.left+r.width/2),Math.round(r.width)]})")
      lab=await pg.evaluate("()=>[...document.querySelectorAll('.t3-foot button')].findIndex(b=>b.getAttribute('aria-pressed')==='true')")
      print('clicked',i,'pressed',lab,'walls',info)
      await pg.screenshot(path=f'/tmp/cn/prof/shots/tour_btn{i}.png')
    await b.close()
asyncio.run(main())
