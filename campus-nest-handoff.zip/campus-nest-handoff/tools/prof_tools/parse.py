import asyncio, json
from playwright.async_api import async_playwright
PH=["Нас трое с AITU, бюджет 240к, есть кот, без курящих","без кота и без собаки, нас двое, 200к","курящих нет, нас двое, 180 тысяч","we are three girls, max 300 000 tenge, no smokers","two of us, two hundred thousand total","нас 7 человек, бюджет 500к","Нас двое, по 90к каждый","мы с другом ищем квартиру до 250к","I'm allergic to cats, need a flat for 2 under 220k","Біз екеуміз, 200 мың, итіміз жоқ","студия до 150к для меня одной, жаворонок","3 comrades budget 100k dog"]
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=await b.new_page(); await pg.goto('file://'+__import__('os').environ.get('APP','/ABS/PATH/TO/index.html')); await pg.wait_for_timeout(1000)
    for t in PH:
      r=await pg.evaluate("(t)=>{const o=parsePlan(t); const pl=buildPlan(o); return {people:o.people,budget:o.budget,per:o.per,pet:o.pet,smoke:o.smoke,type:o.type, n:pl.n, best:pl.best&&pl.best.l.title+' '+pl.best.l.price+' fit'+pl.best.fit+(pl.best.hard?' HARD':''), none:pl.none, mates:pl.mates}}",t)
      print(t,'=>',json.dumps(r,ensure_ascii=False))
    print('visible flats', await pg.evaluate("visFlats().length"), 'all', await pg.evaluate("LISTINGS.length"), 'people', await pg.evaluate("Object.keys(PEOPLE).length"))
    for q in ['Маған кім сәйкес келеді?','Какие правила для группы?','Сколько стоит депозит?','What is the weather?','найди студию до 150к']:
      r=await pg.evaluate("(q)=>offlineAnswer(q)",q); print('Q',q,'=>',r['answer'][:160])
    await b.close()
asyncio.run(main())
