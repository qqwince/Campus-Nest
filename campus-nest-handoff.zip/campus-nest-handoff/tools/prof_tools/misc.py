import asyncio, json
from playwright.async_api import async_playwright
PATH=__import__('os').environ.get('APP','/ABS/PATH/TO/index.html'); SH='/tmp/cn/prof/shots/'
R={}
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=await b.new_page(viewport={'width':1280,'height':800}); errs=[]
    pg.on('pageerror',lambda e: errs.append(str(e)[:200])); pg.on('console',lambda m: errs.append(m.text[:200]) if m.type=='error' else None)
    await pg.goto('file://'+PATH); await pg.wait_for_timeout(1500)
    # A natural network failure
    R['A_mode']=await pg.evaluate('[ST.ai.mode, ST.ai.name, AI_URL]')
    await pg.evaluate("()=>{jump('AI1'); openView('app');}"); await pg.wait_for_timeout(300)
    await pg.locator('.aix-q').first.click(); await pg.wait_for_timeout(2500)
    R['A_header']=await pg.locator('.wtop, .top').first.inner_text()
    R['A_sub']=await pg.evaluate("()=>[...document.querySelectorAll('.sub')].map(e=>e.innerText)")
    R['A_tags']=await pg.evaluate("()=>[...document.querySelectorAll('.aix-meta')].map(e=>e.innerText)")
    await pg.screenshot(path=SH+'misc_A_AI1_netfail.png')
    # double click quick question while busy
    await pg.evaluate("()=>set(s=>{s.aiChat=[]})"); await pg.wait_for_timeout(200)
    q=pg.locator('.aix-q').first; await q.dblclick(); await pg.wait_for_timeout(2500)
    R['F_dbl_quick_msgs']=await pg.evaluate("()=>ST.aiChat.map(m=>m.r)")
    # B scroll jump in AI1 when typing in plan textarea
    await pg.evaluate("()=>set(s=>{s.aiChat=[]})"); await pg.wait_for_timeout(200)
    await pg.evaluate("()=>{const b=document.querySelector('.wbody .body')||document.querySelector('.body'); b.scrollTop=0;}")
    st0=await pg.evaluate("()=>{const b=document.querySelector('.body');return [b.scrollTop,b.scrollHeight,b.clientHeight]}")
    ta=pg.locator('.pv-box textarea').first; await ta.click(); await pg.keyboard.type('Нас двое',delay=40); await pg.wait_for_timeout(300)
    st1=await pg.evaluate("()=>{const b=document.querySelector('.body');return [b.scrollTop,b.scrollHeight,b.clientHeight]}")
    R['B_ai1_scroll_on_typing']=[st0,st1]
    await pg.screenshot(path=SH+'misc_B_AI1_typing.png')
    # C aiOff + learning
    await pg.evaluate("()=>{resetDemo();}")
    s0=await pg.evaluate("()=>Object.keys(PEOPLE).map(k=>[k,score(ST.me,PEOPLE[k])])")
    await pg.evaluate("()=>{jump('S1.2'); openView('app');}"); await pg.wait_for_timeout(300)
    toasts=[]
    for i in range(4):
      btn=pg.locator('button[aria-label="Like"]')
      if await btn.count()==0: break
      await btn.click(); await pg.wait_for_timeout(700)
      toasts.append(await pg.evaluate('ST.toast')); await pg.evaluate("()=>set(s=>{s.sheet=null})"); await pg.wait_for_timeout(200)
    R['C_like_toasts']=toasts; R['C_wmul']=await pg.evaluate('ST.wmul')
    s1=await pg.evaluate("()=>Object.keys(PEOPLE).map(k=>[k,score(ST.me,PEOPLE[k])])")
    await pg.evaluate("()=>set(s=>{s.aiOff=true})")
    s2=await pg.evaluate("()=>Object.keys(PEOPLE).map(k=>[k,score(ST.me,PEOPLE[k])])")
    R['C_scores']={'initial':s0,'after_likes':s1,'aiOff':s2}
    await pg.evaluate("()=>{jump('S1.3'); openView('app');}"); await pg.wait_for_timeout(400)
    R['C_aiOff_S13_text']=(await pg.locator('.wbody').inner_text())[:500]
    await pg.evaluate("()=>{jump('S1.2'); openView('app');}"); await pg.wait_for_timeout(400); await pg.screenshot(path=SH+'misc_C_aiOff_S12.png')
    # G contract screen AI blocks
    await pg.evaluate("()=>{resetDemo(); ensureContract(); jump('S0'); nav('M3.1'); openView('app');}"); await pg.wait_for_timeout(500)
    R['G_M31_ai_blocks']=await pg.evaluate("()=>[...document.querySelectorAll('.ai .k')].map(e=>e.innerText)")
    sb=pg.locator('button:has-text("Scan the contract")')
    await sb.click(); await pg.wait_for_timeout(1500)
    R['G_scan_btn_after_start']=await sb.count()
    await pg.wait_for_timeout(9000)
    R['G_xray_after']=(await pg.locator('.xr-sum').inner_text()) if await pg.locator('.xr-sum').count() else None
    R['G_xray_sum_para']=await pg.evaluate("()=>{const s=document.querySelector('.xr-sum');return s&&s.nextElementSibling&&s.nextElementSibling.innerText}")
    R['G_rescan_available']=await pg.locator('.xr button').count()
    await pg.screenshot(path=SH+'misc_G_M31.png',full_page=False)
    # F apply double send
    await pg.evaluate("()=>{resetDemo(); jump('S2.1'); nav('S4.1',{id:'l3'}); openView('app');}"); await pg.wait_for_timeout(400)
    sendb=pg.locator('.wbody button.btn.p').last; R['F_apply_btn']=await sendb.inner_text()
    await sendb.dblclick(); await pg.wait_for_timeout(800)
    R['F_after_dbl']=await pg.evaluate("()=>[cur().id, JSON.stringify(ST.app&&{lid:ST.app.lid,status:ST.app.status}), ST.notifs.length, (ST.apps||[]).length]")
    # H landing count
    await pg.evaluate("()=>{resetDemo();}"); await pg.wait_for_timeout(400)
    R['H_stats']=await pg.locator('.aih-stats').inner_text()
    R['H_cards']=await pg.locator('.aih-card b').all_inner_texts()
    # hero match explainer
    await pg.locator('.aih-tabs button').nth(1).click(); await pg.wait_for_timeout(1500)
    R['H_match_explainer']=await pg.locator('#aih-demo').inner_text()
    await pg.locator('#aih-demo').screenshot(path=SH+'misc_H_explainer.png')
    # hero ask + continue
    await pg.locator('.aih-tabs button').nth(0).click(); await pg.locator('.aix-hero-in input').fill('кто мне подходит?'); await pg.keyboard.press('Enter'); await pg.wait_for_timeout(2500)
    R['H_ask_ru']=await pg.locator('.aix-hero-chat').inner_text()
    # D presenter tour
    await pg.evaluate("()=>{resetDemo(); presStart(); set(s=>{s.pres={...s.pres,paused:true}});}")
    pres=[]
    for i in range(10):
      await pg.evaluate(f"()=>presGo({i})"); await pg.wait_for_timeout(2600 if i not in (2,7,8) else 7000)
      await pg.evaluate("()=>set(s=>{s.pres={...s.pres,paused:true}})")
      await pg.screenshot(path=SH+f'pres_{i}.png')
      pres.append({'i':i,'view':await pg.evaluate('ST.view'),'id':await pg.evaluate('cur().id'),'sheet':await pg.evaluate('ST.sheet&&ST.sheet.type'),'planOpen':await pg.evaluate('ST.planOpen'),'cap':await pg.locator('.pr-cap').inner_text()})
    R['D_pres']=pres
    await pg.evaluate("()=>presExit()")
    R['errs']=errs
    await pg.close()
    # E dark theme
    for W,Hh in [(1280,800),(390,844)]:
      ctx=await b.new_context(viewport={'width':W,'height':Hh},color_scheme='dark'); pg=await ctx.new_page()
      await pg.goto('file://'+PATH); await pg.wait_for_timeout(1500); await pg.screenshot(path=SH+f'dark_{W}_landing.png')
      for sid in ['AI1','S1.2','S2.1','M3.1','L0']:
        await pg.evaluate(f"()=>{{resetDemo(); if('{sid}'==='M3.1') ensureContract(); jump('{sid}'); openView('app');}}"); await pg.wait_for_timeout(500)
        await pg.screenshot(path=SH+f'dark_{W}_{sid}.png')
      await pg.evaluate("()=>{resetDemo(); startPlan('Two of us, 230k total, 2-room flat near Mangilik El, no pets',{overlay:true}); skipPlan();}"); await pg.wait_for_timeout(1200)
      await pg.screenshot(path=SH+f'dark_{W}_plan.png')
      await pg.evaluate("()=>{ const e=document.querySelector('.pc'); e&&e.scrollIntoView(); }"); await pg.wait_for_timeout(500); await pg.screenshot(path=SH+f'dark_{W}_plancard.png')
      await ctx.close()
    await b.close()
  json.dump(R,open('/tmp/cn/prof/misc.json','w'),ensure_ascii=False,indent=1); print(json.dumps(R,ensure_ascii=False,indent=1)[:9000])
asyncio.run(main())
