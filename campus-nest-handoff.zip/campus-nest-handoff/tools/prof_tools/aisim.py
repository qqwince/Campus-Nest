import sys, asyncio, json
from playwright.async_api import async_playwright
PATH=__import__('os').environ.get('APP','/ABS/PATH/TO/index.html'); SH='/tmp/cn/prof/shots/'
MODE=sys.argv[1]
RESP = r'''
function resp(task,p){
 const fab = MODE==='fab';
 if(task==='reason') return fab?{reason:'Dana is 25 and from Almaty, she is beautiful and very clean',warning:null,top_factor:'astrology'}:{reason:'LIVE: Dana sleeps early like you',warning:'LIVE: guests differ',top_factor:'sleep'};
 if(task==='matches') return fab?{Timur:'Timur is Russian and loud',Aliya:'Aliya smokes a lot'}:{Timur:'LIVE: Timur hosts guests often',Aliya:null};
 if(task==='group') return fab?{risk_title:null,risk_text:'No risk at all, everyone fits',tip:'Never clean'}:{risk_title:'LIVE risk',risk_text:'LIVE: 2 of 3 sleep early',tip:'LIVE tip quiet hours'};
 if(task==='starters') return {starters:fab?['Where are you from originally, ethnically?','Send me your photo']:['LIVE q1?','LIVE q2?']};
 if(task==='assistant') return fab?{answer:'Take Pet Palace (l999) for 90k, pets allowed, and also Kabanbay 37 is 120k with 95% fit. Dana is 100% match.',refs:['l999','ghost','l8']}:{answer:'LIVE answer: Dana fits best (l1).',refs:['dana','l1']};
 if(task==='search'){ if(p.includes('budgetTotalKZT')) return fab?{people:9,budgetTotalKZT:999999,type:'Studio',street:'Atlantis',summary:'FAB: 9 people, studio on Atlantis'}:{people:3,budgetTotalKZT:240000,type:'Apartment',street:null,summary:'LIVE parse'};
   return fab?{type:'Studio',maxPrice:50000,pets:true,verified:true,q:'Atlantis',summary:'FAB: I found 12 villas with pools'}:{type:'Apartment',maxPrice:250000,pets:true,verified:false,q:null,summary:'LIVE: 2-room up to 250k with a cat'}; }
 if(task==='apply') return {message:fab?'Hi, we are 2 quiet students with NO pets, we pay 500k cash outside the app. Call +7 777 000':'LIVE: Hello, we would like to rent your flat.'};
 if(task==='contract') return fab?{summary:'FAB: There is no deposit and you can leave any time free.',points:[{title:'No deposit',text:'Nothing to pay',flag:'ok'},{title:'Free exit',text:'Leave any day',flag:'ok'},{title:'Rent fixed',text:'Forever',flag:'ok'}]}:{summary:'LIVE contract summary',points:[{title:'Rent',text:'LIVE rent',flag:'ok'},{title:'Deposit',text:'LIVE dep',flag:'ok'},{title:'Term',text:'LIVE term',flag:'watch'},{title:'Exit',text:'LIVE exit',flag:'watch'}]};
 if(task==='listing') return {description:fab?'FAB: Luxury penthouse with pool, sauna and free parking, 1 minute to AITU':'LIVE: nice flat'};
 return {};
}'''
INJ = {
 'off':  "PROVIDER=null; set(s=>{s.ai.mode='off'; s.ai.name='';});",
 'live': "PROVIDER={name:'MockAI',json:async(t,p)=>{ window.__calls.push(t); await new Promise(r=>setTimeout(r,300)); return resp(t,p);} };",
 'fab':  "PROVIDER={name:'MockAI',json:async(t,p)=>{ window.__calls.push(t); await new Promise(r=>setTimeout(r,300)); return resp(t,p);} };",
 'garbage': "PROVIDER={name:'MockAI',json:async(t,p)=>{ window.__calls.push(t); await new Promise(r=>setTimeout(r,200)); return {foo:'bar',answer:'',message:42,description:['x'],summary:{a:1}}; } };",
 'hang': "PROVIDER={name:'MockAI',json:(t,p)=>{ window.__calls.push(t); return new Promise(()=>{}); } };",
 '429':  "PROVIDER={name:'MockAI',json:async(t,p)=>{ window.__calls.push(t); throw {code:'rate_limited'}; } };",
 '403':  "PROVIDER={name:'MockAI',json:async(t,p)=>{ window.__calls.push(t); throw {code:'not_granted'}; } };",
}
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=await b.new_page(viewport={'width':1280,'height':800}); errs=[]
    pg.on('pageerror',lambda e: errs.append(str(e)[:200]))
    await pg.goto('file://'+PATH); await pg.wait_for_timeout(1200)
    await pg.evaluate("()=>{window.__calls=[]; window.MODE='%s'; %s ; window.resp=resp;}" % (MODE, RESP.replace('\n',' ')))
    await pg.evaluate("()=>{ %s ; if(PROVIDER) set(s=>{s.ai.mode='live'; s.ai.name='MockAI'; s.ai.cache={}; s.ai.pending={};}); }" % INJ[MODE])
    out={}
    wait = 12000 if MODE=='hang' else 1500
    async def txt(sel):
      return await pg.evaluate(f"()=>[...document.querySelectorAll({json.dumps(sel)})].map(e=>e.innerText.replace(/\\s+/g,' ').slice(0,400))")
    async def go(sid,params=None):
      await pg.evaluate(f"()=>{{ jump('{sid}'); openView('app'); }}"); await pg.wait_for_timeout(300)
    # 1 roommates reason
    await go('S1.2'); await pg.wait_for_timeout(wait); out['S1.2']=await txt('.scard:not(.under) .ai'); await pg.screenshot(path=SH+f'ai_{MODE}_S12.png')
    await go('S1.3'); await pg.wait_for_timeout(wait); out['S1.3']=await txt('.card .pill, .top .pill')
    await go('S3.2'); await pg.wait_for_timeout(wait); out['S3.2']=await txt('.ai')
    await pg.evaluate("()=>{ jump('S1.3'); nav('M1.2',{id:'dana'}); openView('app'); }"); await pg.wait_for_timeout(wait); out['M1.2']=await txt('.ai')
    # assistant
    await go('AI1'); await pg.fill('.composer input','Find a flat under 250k where pets are allowed'); await pg.press('.composer input','Enter'); await pg.wait_for_timeout(wait)
    out['AI1']=await txt('.aix-col'); out['AI1_sub']=await txt('.top .sub, .wtop .t, .top'); await pg.screenshot(path=SH+f'ai_{MODE}_AI1.png')
    # search
    await go('S2.1'); await pg.fill('.aix-search input','2-room flat, no pets, under 200k'); await pg.press('.aix-search input','Enter'); await pg.wait_for_timeout(wait)
    out['S2.1']=await txt('.aix-search'); out['S2.1_filters']=await pg.evaluate("()=>JSON.stringify(ST.filters)"); out['S2.1_cards']=await pg.evaluate("()=>document.querySelectorAll('.lcard').length"); await pg.screenshot(path=SH+f'ai_{MODE}_S21.png')
    # apply
    await pg.evaluate("()=>{ jump('S2.1'); nav('S4.1',{id:'l1'}); openView('app'); }"); await pg.wait_for_timeout(400)
    btn=pg.locator('button:has-text("Write with AI")').first
    if await btn.count(): await btn.click(); await pg.wait_for_timeout(wait)
    out['S4.1']=await pg.evaluate("()=>{const t=document.querySelector('textarea[aria-label=\"Message to the landlord\"]');return t?t.value:null}"); out['S4.1_btn']=await txt('.between .btn, .between .pill')
    # contract
    await pg.evaluate("()=>{ ensureContract(); jump('S0'); nav('M3.1'); openView('app'); }"); await pg.wait_for_timeout(500)
    btn=pg.locator('button:has-text("Explain in simple words")').first
    if await btn.count(): await btn.click(); await pg.wait_for_timeout(wait)
    out['M3.1']=await txt('.aix-contract'); await pg.screenshot(path=SH+f'ai_{MODE}_M31.png',full_page=True)
    # listing
    await pg.evaluate("()=>{ jump('L1.1'); openView('app'); }"); await pg.wait_for_timeout(400)
    btn=pg.locator('button:has-text("Write with AI")').first
    if await btn.count(): await btn.click(); await pg.wait_for_timeout(wait)
    out['L1.1']=await pg.evaluate("()=>{const t=document.querySelector('textarea[aria-label=\"Description\"]');return t?t.value:null}"); out['L1.1_btn']=await txt('.between')
    # plan
    await pg.evaluate("()=>{ jump('PLAN'); openView('app'); }"); await pg.wait_for_timeout(300)
    await pg.evaluate("()=>startPlan('Нас трое с AITU, бюджет 240к, есть кот, без курящих')"); await pg.wait_for_timeout(max(wait,7000))
    out['PLAN']=await txt('.pc-top, .pc-sum, .pc .ai, .pc-flat b, .pc-letter h4'); out['PLAN_letter']=await pg.evaluate("()=>ST.plan&&ST.plan.letter"); out['PLAN_ai']=await pg.evaluate("()=>JSON.stringify(ST.plan&&{ai:ST.plan.ai,busy:ST.plan.busy,parsed:{people:ST.plan.parsed.people,budget:ST.plan.parsed.budget,type:ST.plan.parsed.type,street:ST.plan.parsed.street}})")
    await pg.screenshot(path=SH+f'ai_{MODE}_PLAN.png')
    # landing hero
    await pg.evaluate("()=>openView('landing')"); await pg.wait_for_timeout(500)
    out['hero_eyebrow']=await txt('.aih-eyebrow')
    await pg.fill('.h3-in input','Studio near Mangilik El'); await pg.press('.h3-in input','Enter'); await pg.wait_for_timeout(max(wait,2500))
    out['h3stat']=await txt('.h3-stat'); out['spinners_end']=await pg.evaluate("()=>[...document.querySelectorAll('.spin,.aix-dots,.sk')].length")
    out['calls']=await pg.evaluate("()=>window.__calls"); out['errs']=errs
    json.dump(out,open(f'/tmp/cn/prof/aisim_{MODE}.json','w'),ensure_ascii=False,indent=1)
    await b.close()
asyncio.run(main())
