import asyncio, json
from playwright.async_api import async_playwright
PATH=__import__('os').environ.get('APP','/ABS/PATH/TO/index.html'); SH='/tmp/cn/prof/shots/'
R={}
async def rig(pg): return await pg.evaluate("()=>{const r=document.querySelector('.h3-rig');return r?[parseFloat(r.style.getPropertyValue('--ry')),parseFloat(r.style.getPropertyValue('--rx'))]:null}")
async def trig(pg): return await pg.evaluate("()=>{const r=document.querySelector('.t3-rig');return r?[parseFloat(r.style.getPropertyValue('--ty')),parseFloat(r.style.getPropertyValue('--tp'))]:null}")
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    # ---------- desktop House3D ----------
    pg=await b.new_page(viewport={'width':1280,'height':800}); await pg.goto('file://'+PATH); await pg.wait_for_timeout(1500)
    box=await pg.locator('.h3-scene').bounding_box(); R['h3_box_1280']=box
    cx,cy=box['x']+box['width']/2, box['y']+box['height']/2
    await pg.mouse.move(cx,cy); await pg.wait_for_timeout(600); a=await rig(pg)
    await pg.mouse.move(cx+200,cy); await pg.wait_for_timeout(800); bb=await rig(pg)
    R['hover_no_click_rotates']=[a,bb]
    # drag left by 300
    await pg.mouse.move(cx,cy); await pg.mouse.down(); 
    for i in range(10): await pg.mouse.move(cx-30*(i+1),cy+8*(i+1)); await pg.wait_for_timeout(16)
    await pg.wait_for_timeout(700); d1=await rig(pg); await pg.mouse.up(); await pg.wait_for_timeout(100); d2=await rig(pg)
    await pg.mouse.move(cx-300+5,cy+80); await pg.wait_for_timeout(900); d3=await rig(pg)
    R['drag_then_tiny_move']={'during':d1,'after_up':d2,'after_5px_move':d3}
    # leave and idle
    await pg.mouse.move(5,790); await pg.wait_for_timeout(2500); R['idle_after_leave']=await rig(pg)
    # wheel over scene
    y0=await pg.evaluate('scrollY'); await pg.mouse.move(cx,cy); await pg.mouse.wheel(0,400); await pg.wait_for_timeout(500); y1=await pg.evaluate('scrollY'); R['wheel_scrolls_page']=[y0,y1, await rig(pg)]
    await pg.evaluate('scrollTo(0,0)'); await pg.wait_for_timeout(300)
    # keyboard focusability
    R['scene_tabindex']=await pg.evaluate("()=>document.querySelector('.h3-scene').tabIndex")
    # click a window
    u=pg.locator('.h3-u:not(.empty)').first; ub=await u.bounding_box(); R['unit_box']=ub
    await u.click(); await pg.wait_for_timeout(500); R['unit_click_card']=await pg.locator('.h3-card').count()
    await pg.screenshot(path=SH+'3d_house_1280.png')
    # small units size
    R['unit_sizes']=await pg.evaluate("()=>[...document.querySelectorAll('.h3-u')].map(e=>{const r=e.getBoundingClientRect();return [Math.round(r.width),Math.round(r.height)]})")
    # drag starting on a window: does it select?
    ub=await pg.locator('.h3-u:not(.empty)').nth(2).bounding_box()
    await pg.evaluate("()=>set(s=>{})")
    await pg.mouse.move(ub['x']+ub['width']/2,ub['y']+ub['height']/2); await pg.mouse.down(); await pg.mouse.move(ub['x']+150,ub['y']+10,steps=8); await pg.mouse.up(); await pg.wait_for_timeout(400)
    R['drag_from_window_selects']=await pg.evaluate("()=>document.querySelector('.h3-card b')&&document.querySelector('.h3-card b').innerText")
    # 3D tour open from card
    t=pg.locator('.h3-card button:has-text(\"3D tour\")')
    if await t.count():
      await t.click(); await pg.wait_for_timeout(800)
      await pg.screenshot(path=SH+'3d_tour_1280.png')
      vb=await pg.locator('.t3-view').bounding_box(); vx,vy=vb['x']+vb['width']/2, vb['y']+vb['height']/2
      s0=await trig(pg); await pg.wait_for_timeout(1000); s1=await trig(pg); R['tour_autorotate_1s']=[s0,s1]
      await pg.mouse.move(vx,vy); await pg.mouse.down(); await pg.mouse.move(vx+200,vy+100,steps=10); await pg.wait_for_timeout(500); dd=await trig(pg); await pg.mouse.up(); await pg.wait_for_timeout(1500); de=await trig(pg)
      R['tour_drag_right_down']={'during':dd,'after_release_1.5s':de}
      y0=await pg.evaluate('scrollY'); await pg.mouse.wheel(0,600); await pg.wait_for_timeout(400); R['tour_wheel']=[y0,await pg.evaluate('scrollY'),await trig(pg)]
      await pg.keyboard.press('ArrowRight'); await pg.wait_for_timeout(500); R['tour_key_right']=await trig(pg)
      R['tour_hint']=await pg.locator('.t3-hint').inner_text()
      R['tour_wall_btns']=await pg.locator('.t3-foot button').all_inner_texts()
      # Tab focus escape
      foc=[]
      for i in range(8):
        await pg.keyboard.press('Tab'); foc.append(await pg.evaluate("()=>{const a=document.activeElement;return (a.closest('.t3')?'IN:':'OUT:')+(a.innerText||a.getAttribute('aria-label')||a.tagName).slice(0,25)}"))
      R['tour_tab_order']=foc
      # presenter + arrow
      await pg.keyboard.press('Escape'); await pg.wait_for_timeout(300); R['tour_closed_by_esc']=await pg.locator('.t3').count()==0
    # tour + presenter conflict
    await pg.evaluate("()=>{ presStart(); }"); await pg.wait_for_timeout(500)
    await pg.evaluate("()=>{ presGo(3); }"); await pg.wait_for_timeout(1500)
    await pg.evaluate("()=>set(s=>{s.pres={...s.pres,paused:true}})")
    btn=pg.locator('.pc-flat button:has-text(\"3D tour\")')
    if await btn.count():
      await btn.click(); await pg.wait_for_timeout(500); i0=await pg.evaluate('ST.pres.i')
      await pg.keyboard.press('ArrowRight'); await pg.wait_for_timeout(600); i1=await pg.evaluate('ST.pres.i'); tourOpen=await pg.locator('.t3').count()
      await pg.keyboard.press('Escape'); await pg.wait_for_timeout(300)
      R['presenter_tour_conflict']={'pres_i_before':i0,'after_arrow':i1,'tour_open_after_arrow':tourOpen,'tour_open_after_esc':await pg.locator('.t3').count(),'pres_on_after_esc':await pg.evaluate('ST.pres.on')}
      await pg.screenshot(path=SH+'3d_tour_pres.png')
    await pg.evaluate("()=>{presExit(); set(s=>{s.tour=null}); resetDemo();}"); await pg.wait_for_timeout(400)
    # What-if slider arrow in presenter
    await pg.evaluate("()=>{ presStart(); set(s=>{s.pres={...s.pres,paused:true}}); jump('S1.2'); openView('app'); sheet('whatif'); }"); await pg.wait_for_timeout(600)
    sl=pg.locator('.wi-c input[type=range]').first
    if await sl.count():
      await sl.focus(); i0=await pg.evaluate('ST.pres.i'); await pg.keyboard.press('ArrowRight'); await pg.wait_for_timeout(600)
      R['presenter_slider_arrow']={'i0':i0,'i1':await pg.evaluate('ST.pres.i'),'sheet':await pg.evaluate('ST.sheet&&ST.sheet.type'),'wi':await pg.evaluate('JSON.stringify(ST.wi)')}
    await pg.evaluate("()=>{presExit(); resetDemo();}")
    # ---------- PlanScene ----------
    await pg.evaluate("()=>startPlan('Нас трое с AITU, бюджет 240к, есть кот, без курящих',{overlay:true})")
    for ph in [0,1,2,3,4]:
      await pg.wait_for_timeout(1350); await pg.screenshot(path=SH+f'3d_plan_1280_t{ph}.png')
    R['plan_scene_interactive']=await pg.evaluate("()=>{const e=document.querySelector('.ps');return {role:e.getAttribute('role'),tab:e.tabIndex,cursor:getComputedStyle(e).cursor}}")
    # drag on plan scene
    pb=await pg.locator('.ps').bounding_box(); w0=await pg.evaluate("()=>document.querySelector('.ps-w').style.getPropertyValue('--a')")
    await pg.mouse.move(pb['x']+pb['width']/2,pb['y']+pb['height']/2); await pg.mouse.down(); await pg.mouse.move(pb['x']+pb['width']/2+200,pb['y']+pb['height']/2,steps=8); await pg.mouse.up()
    await pg.wait_for_timeout(300); R['plan_drag_effect']=[w0,await pg.evaluate("()=>document.querySelector('.ps-w').style.getPropertyValue('--a')")]
    # labels overlap
    R['plan_labels_overlap']=await pg.evaluate("""()=>{const ls=[...document.querySelectorAll('.pl2 i')].filter(i=>getComputedStyle(i).opacity>0.1).map(i=>{const r=i.getBoundingClientRect();return {t:i.innerText,r}});let o=[];for(let a=0;a<ls.length;a++)for(let b=a+1;b<ls.length;b++){const A=ls[a].r,B=ls[b].r; if(A.left<B.right&&B.left<A.right&&A.top<B.bottom&&B.top<A.bottom) o.push(ls[a].t+' x '+ls[b].t);} return {n:ls.length,o}}""")
    y0=await pg.evaluate('scrollY'); await pg.mouse.wheel(0,500); await pg.wait_for_timeout(300); R['plan_overlay_wheel_page']=[y0,await pg.evaluate('scrollY'), await pg.evaluate("()=>document.querySelector('.po')&&document.querySelector('.po').scrollTop")]
    await pg.close()
    # ---------- mobile with touch ----------
    ctx=await b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,device_scale_factor=2)
    pg=await ctx.new_page(); await pg.goto('file://'+PATH); await pg.wait_for_timeout(1500)
    sc=pg.locator('.h3-scene'); await sc.scroll_into_view_if_needed(); await pg.wait_for_timeout(300)
    box=await sc.bounding_box(); R['h3_box_390']=box
    cdp=await ctx.new_cdp_session(pg)
    async def swipe(x0,y0,x1,y1,steps=10):
      await cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':x0,'y':y0}]})
      for i in range(1,steps+1):
        await cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x0+(x1-x0)*i/steps,'y':y0+(y1-y0)*i/steps}]}); await pg.wait_for_timeout(16)
      await cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]})
    cx,cy=box['x']+box['width']/2, box['y']+box['height']/2
    r0=await rig(pg); sy0=await pg.evaluate('scrollY')
    await swipe(cx+100,cy,cx-100,cy); await pg.wait_for_timeout(400); r1=await rig(pg)
    await swipe(cx,cy+80,cx,cy-120); await pg.wait_for_timeout(400); r2=await rig(pg); sy1=await pg.evaluate('scrollY')
    R['touch_h3']={'start':r0,'after_hswipe':r1,'after_vswipe':r2,'scroll':[sy0,sy1]}
    await pg.screenshot(path=SH+'3d_house_390.png')
    R['unit_sizes_390']=await pg.evaluate("()=>[...document.querySelectorAll('.h3-u')].map(e=>{const r=e.getBoundingClientRect();return [Math.round(r.width),Math.round(r.height)]})")
    R['hint_390']=await pg.locator('.h3-hint').inner_text()
    # tap a window
    u=pg.locator('.h3-u:not(.empty)').first; await u.tap(); await pg.wait_for_timeout(400); R['tap_unit_390']=await pg.locator('.h3-card').count()
    t=pg.locator('.h3-card button:has-text(\"3D tour\")')
    if await t.count():
      await t.tap(); await pg.wait_for_timeout(800)
      vb=await pg.locator('.t3-view').bounding_box(); vx,vy=vb['x']+vb['width']/2, vb['y']+vb['height']/2
      a=await trig(pg); await swipe(vx+120,vy,vx-120,vy); await pg.wait_for_timeout(500); bq=await trig(pg)
      R['touch_tour_swipe_left']=[a,bq]
      await pg.screenshot(path=SH+'3d_tour_390.png')
      # pinch? not supported
      R['tour_pinch_supported']=await pg.evaluate("()=>/wheel|gesture|touches.length/.test(TourOverlay.toString())")
      await pg.locator('.t3-x').tap(); await pg.wait_for_timeout(300)
    await pg.evaluate("()=>startPlan('Нас трое с AITU, бюджет 240к, есть кот, без курящих',{overlay:true})")
    await pg.wait_for_timeout(2900); await pg.screenshot(path=SH+'3d_plan_390_t2.png'); await pg.wait_for_timeout(3500); await pg.screenshot(path=SH+'3d_plan_390_t4.png')
    R['plan_labels_overlap_390']=await pg.evaluate("""()=>{const ls=[...document.querySelectorAll('.pl2 i')].filter(i=>getComputedStyle(i).opacity>0.1).map(i=>{const r=i.getBoundingClientRect();return {t:i.innerText,r}});let o=[];for(let a=0;a<ls.length;a++)for(let b=a+1;b<ls.length;b++){const A=ls[a].r,B=ls[b].r; if(A.left<B.right&&B.left<A.right&&A.top<B.bottom&&B.top<A.bottom) o.push(ls[a].t+' x '+ls[b].t);} return {n:ls.length,o}}""")
    await b.close()
  json.dump(R,open('/tmp/cn/prof/t3d.json','w'),ensure_ascii=False,indent=1); print(json.dumps(R,ensure_ascii=False,indent=1))
asyncio.run(main())
