import worker from './worker.v3.js';
const KEY = 'SECRET-KEY-abc123XYZ';
const ORIGIN = 'https://nest.example';
let ipN = 0, pass = 0, fail = 0;
const logs = [];
for (const k of ['log', 'warn', 'error', 'info', 'debug']) console[k] = (...a) => logs.push(a.map(String).join(' '));
const out = (...a) => process.stdout.write(a.join(' ') + '\n');
const bodies = [];
function req(task, prompt, o = {}) {
  const b = o.raw ?? JSON.stringify({ task, prompt });
  return new Request('https://w.example/', { method: o.method || 'POST', headers: { Origin: o.origin ?? ORIGIN, 'CF-Connecting-IP': o.ip || ('1.1.1.' + (++ipN)) }, body: o.method === 'GET' ? undefined : b });
}
async function run(r, env) { const res = await worker.fetch(r, env); const t = await res.text(); bodies.push(t); return { status: res.status, json: JSON.parse(t), headers: res.headers }; }
function t(name, c) { if (c) { pass++; out('ok  ', name); } else { fail++; out('FAIL', name); } }
const gOk = (obj) => new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: JSON.stringify(obj) }] } }] }), { status: 200 });
let calls, seen;
function mockFetch(fn) { calls = []; globalThis.fetch = async (url, init) => { calls.push({ url, init }); return fn(url, init, calls.length); }; }
const AIok = { run: async () => ({ response: '{"w":1}' }) };
const base = { ALLOWED_ORIGIN: ORIGIN, GEMINI_API_KEY: KEY };
const P = 'You are the Campus Nest assistant: hi';

let r;
mockFetch(() => gOk({ a: 1 }));
r = await run(req('assistant', P), { ...base, AI: AIok });
t('gemini ok', r.status === 200 && r.json.provider === 'gemini' && r.json.model === 'gemini-3.5-flash' && r.json.data.a === 1 && typeof r.json.ms === 'number');
const c0 = calls[0];
const sent = JSON.parse(c0.init.body);
t('key in header not URL', c0.init.headers['x-goog-api-key'] === KEY && !c0.url.includes(KEY) && !c0.init.body.includes(KEY));
t('request shape', sent.contents[0].role === 'user' && sent.contents[0].parts[0].text === P && sent.generationConfig.responseMimeType === 'application/json' && sent.generationConfig.maxOutputTokens === 1500 && !sent.systemInstruction.parts[0].text.includes('Campus Nest assistant: hi') && c0.url.endsWith('/gemini-3.5-flash:generateContent'));

mockFetch((u, i, n) => n === 1 ? new Response('{}', { status: 429 }) : gOk({ b: 2 }));
r = await run(req('assistant', P), { ...base, AI: AIok });
t('429 -> second gemini model', r.json.provider === 'gemini' && r.json.model === 'gemini-3.1-flash-lite' && calls.length === 2);

mockFetch(() => new Response('{}', { status: 503 }));
r = await run(req('assistant', P), { ...base, AI: AIok });
t('both gemini fail -> workers-ai', r.json.provider === 'workers-ai' && r.json.data.w === 1 && calls.length === 2);

const AIbad = { run: async () => { throw new Error('boom'); } };
r = await run(req('assistant', P), { ...base, AI: AIbad });
t('everything fails -> 502 no_model', r.status === 502 && r.json.error === 'no_model');

mockFetch(() => { throw new Error('should not be called'); });
r = await run(req('assistant', P), { ALLOWED_ORIGIN: ORIGIN, AI: AIok });
t('no key -> workers-ai directly', r.json.provider === 'workers-ai' && calls.length === 0);

mockFetch(() => new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: 'not json at all' }] } }] }), { status: 200 }));
r = await run(req('assistant', P), { ...base, AI: AIok });
t('garbage JSON -> next', r.json.provider === 'workers-ai' && calls.length === 2);
r = await run(req('assistant', P), { ...base, AI: { run: async () => ({ response: 'nope' }) } });
t('garbage everywhere -> 502 bad_json', r.status === 502 && r.json.error === 'bad_json');

mockFetch((u, init) => new Promise((_, rej) => init.signal.addEventListener('abort', () => rej(Object.assign(new Error('x'), { name: 'AbortError' })))));
r = await run(req('assistant', P), { ...base, GEMINI_TIMEOUT_MS: '40', AI: AIok });
t('timeout -> workers-ai', r.json.provider === 'workers-ai' && calls.length === 2);
r = await run(req('assistant', P), { ...base, GEMINI_TIMEOUT_MS: '40', AI: AIbad });
t('timeout + AI fail -> 502', r.status === 502 && r.json.reasons.includes('gemini:timeout'));

mockFetch(() => new Response('{}', { status: 403 }));
r = await run(req('assistant', P), { ...base, AI: { run: async () => { throw new Error('403 forbidden'); } } });
t('403 everywhere -> not_granted', r.status === 502 && r.json.error === 'not_granted');
mockFetch(() => new Response('{}', { status: 429 }));
r = await run(req('assistant', P), { ...base, AI: { run: async () => { throw new Error('daily neuron limit'); } } });
t('quota everywhere -> 429 rate_limited', r.status === 429 && r.json.error === 'rate_limited' && r.json.retryAfter > 0);

mockFetch(() => gOk({ plan: 'x' }));
r = await run(req('plan', 'You decide the best housing plan\n' + 'x'.repeat(8000)), { ...base, AI: AIok });
t('plan ok, 2500 tokens', r.status === 200 && JSON.parse(calls[0].init.body).generationConfig.maxOutputTokens === 2500);
r = await run(req('plan', 'You decide the best housing plan' + 'x'.repeat(9000)), { ...base, AI: AIok });
t('plan prompt >9000 -> 400', r.status === 400);
r = await run(req('assistant', P + 'x'.repeat(4000)), { ...base, AI: AIok });
t('ordinary prompt >4000 -> 400', r.status === 400);
r = await run(req('assistant', 'hello'), { ...base, AI: AIok });
t('wrong prefix -> 400', r.status === 400);
r = await run(req('nope', 'x'), { ...base, AI: AIok });
t('unknown task -> 400', r.status === 400);

mockFetch(() => gOk({ ok: true }));
r = await run(req('ping'), { ...base, AI: AIok });
const pb = JSON.parse(calls[0].init.body);
t('ping gemini', r.status === 200 && r.json.ok === true && r.json.provider === 'gemini' && r.json.model && typeof r.json.ms === 'number' && pb.contents[0].parts[0].text === 'Reply with {"ok":true}' && pb.generationConfig.maxOutputTokens <= 20);
mockFetch(() => new Response('{}', { status: 500 }));
r = await run(req('ping'), { ...base, AI: AIok });
t('ping falls to workers-ai', r.json.ok === true && r.json.provider === 'workers-ai');

r = await run(req('assistant', P, { origin: 'https://evil.example' }), { ...base, AI: AIok });
t('bad origin 403', r.status === 403);
r = await run(req('assistant', P), { GEMINI_API_KEY: KEY, AI: AIok });
t('no ALLOWED_ORIGIN 403 with hint', r.status === 403 && /ALLOWED_ORIGIN/.test(r.json.error) && /ALLOW_ANY/.test(r.json.error));
mockFetch(() => gOk({ a: 1 }));
r = await run(req('assistant', P, { origin: 'http://localhost:5' }), { GEMINI_API_KEY: KEY, ALLOW_ANY: '1', AI: AIok });
t('ALLOW_ANY works', r.status === 200 && r.headers.get('access-control-allow-origin') === '*');

const big = JSON.stringify({ task: 'plan', prompt: 'You decide the best housing plan' + 'я'.repeat(17000) });
r = await run(req(null, null, { raw: big }), { ...base, AI: AIok });
t('real body >32KB (no content-length) -> 413', r.status === 413);
r = await run(req(null, null, { raw: '{bad' }), { ...base, AI: AIok });
t('bad JSON body -> 400', r.status === 400);

const ipx = '9.9.9.9', envR = { ...base, RATE_PER_MIN: '3', AI: AIok };
let last; for (let i = 0; i < 4; i++) last = await run(req('assistant', P, { ip: ipx }), envR);
t('rate limit 429 + retryAfter', last.status === 429 && last.json.error === 'rate_limited' && last.json.retryAfter > 0 && last.headers.get('retry-after'));

r = await run(req(null, null, { method: 'GET' }), { ...base, AI: AIok });
t('GET status', r.status === 200 && r.json.ok === true && r.json.gemini === true && r.json.workersAi === true && r.json.version === 'v3');
r = await run(req(null, null, { method: 'GET' }), {});
t('GET status without secrets', r.json.gemini === false && r.json.workersAi === false);

t('key absent from all responses', !bodies.some(b => b.includes(KEY)));
t('key absent from console output', !logs.some(l => l.includes(KEY)));
out(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
